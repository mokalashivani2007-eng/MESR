import { Medicine } from '../types';
import { getTodayKolkataString, parseDateOnlyToMidnightUTC } from './expiry';

export function getSampleMedicines(): Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>[] {
  const todayStr = getTodayKolkataString();
  const todayMidnight = parseDateOnlyToMidnightUTC(todayStr);

  const addDays = (days: number): string => {
    const d = new Date(todayMidnight + days * 86400 * 1000);
    return d.toISOString().split('T')[0];
  };

  return [
    {
      name: 'Ashwagandha Churna',
      batchNumber: 'SAMPLE-ASH-201',
      quantity: 45,
      unit: 'Grams (100g Jar)',
      category: 'Churna',
      manufacturingDate: addDays(-365),
      expiryDate: addDays(-5), // Expired 5 days ago
      supplier: 'Kottakkal Arya Vaidya Sala',
      supplierContact: '+91 483 2742216',
      storageLocation: 'Rack A-01 (Dry Store)',
      description: 'Classical adaptogenic herbal powder for vitality and stress relief',
      notes: 'SAMPLE RECORD: Fictional expired batch for alert verification',
      isSample: true,
    },
    {
      name: 'Brahmi Vati (Gold Coated)',
      batchNumber: 'SAMPLE-BRH-104',
      quantity: 120,
      unit: 'Tablets (Bottle of 60)',
      category: 'Vati/Gutika',
      manufacturingDate: addDays(-180),
      expiryDate: addDays(0), // Expires TODAY
      supplier: 'Dhootapapeshwar Ltd',
      supplierContact: '+91 22 2382 5888',
      storageLocation: 'Rack B-03 (Dispensing Counter)',
      description: 'Nootropic memory and cognitive support formulation',
      notes: 'SAMPLE RECORD: Fictional batch expiring today',
      isSample: true,
    },
    {
      name: 'Triphala Guggulu',
      batchNumber: 'SAMPLE-TRP-508',
      quantity: 250,
      unit: 'Tablets (Bottle of 100)',
      category: 'Guggulu',
      manufacturingDate: addDays(-200),
      expiryDate: addDays(7), // Expiring in 7 days
      supplier: 'Baidyanath Ayurved',
      supplierContact: '+91 33 2287 4099',
      storageLocation: 'Shelf C-12',
      description: 'Digestive detoxifier and inflammatory regulator',
      notes: 'SAMPLE RECORD: Fictional batch expiring in 7 days',
      isSample: true,
    },
    {
      name: 'Dhanwantharam Thailam (101 Avarthanam)',
      batchNumber: 'SAMPLE-DHN-772',
      quantity: 15,
      unit: 'Bottles (450ml)',
      category: 'Taila',
      manufacturingDate: addDays(-30),
      expiryDate: addDays(180), // Safe (in 6 months)
      supplier: 'AVP Coimbatore',
      supplierContact: '+91 422 236 1000',
      storageLocation: 'Oil Vault A',
      description: 'Premium medicated oil for Panchakarma neuromuscular therapies',
      notes: 'SAMPLE RECORD: Fictional safe batch',
      isSample: true,
    },
    {
      name: 'Amritarishta',
      batchNumber: 'SAMPLE-AMR-331',
      quantity: 8, // Low stock demo (< 10)
      unit: 'Bottles (450ml)',
      category: 'Asava/Arishta',
      manufacturingDate: addDays(-60),
      expiryDate: addDays(45), // Safe (in 45 days) but low stock
      supplier: 'Kerala Ayurveda Ltd',
      supplierContact: '+91 484 247 6660',
      storageLocation: 'Rack D-04',
      description: 'Fermented decoction for chronic fever and immunity enhancement',
      notes: 'SAMPLE RECORD: Fictional low-stock batch',
      isSample: true,
    },
  ];
}
