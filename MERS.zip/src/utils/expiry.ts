import { CalculatedMedicine, ExpiryStatus, Medicine, HospitalSettings, AlertType } from '../types';

/**
 * Returns today's date formatted as YYYY-MM-DD in Asia/Kolkata timezone.
 */
export function getTodayKolkataString(dateObj: Date = new Date()): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    return formatter.format(dateObj); // returns "YYYY-MM-DD"
  } catch {
    // Fallback if Intl timeZone fails
    const offset = 5.5 * 60 * 60 * 1000;
    const kolkataDate = new Date(dateObj.getTime() + offset);
    return kolkataDate.toISOString().split('T')[0];
  }
}

/**
 * Parses a YYYY-MM-DD string into a normalized epoch timestamp representing UTC midnight of that calendar date.
 */
export function parseDateOnlyToMidnightUTC(dateStr: string): number {
  if (!dateStr) return NaN;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return NaN;
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  return Date.UTC(year, month, day);
}

/**
 * Normalizes user-entered or spreadsheet dates into standard YYYY-MM-DD.
 * Supports:
 * - YYYY-MM-DD
 * - DD/MM/YYYY or DD-MM-YYYY
 * - MM/DD/YYYY
 * - Excel serial date numbers (e.g., 45582)
 * - ISO strings
 */
export function normalizeDateString(raw: any): string | null {
  if (raw === null || raw === undefined || raw === '') return null;

  // Handle Excel numeric serial dates (days since 1899-12-30)
  if (typeof raw === 'number' || (!isNaN(Number(raw)) && !String(raw).includes('-') && !String(raw).includes('/'))) {
    const num = Number(raw);
    if (num > 20000 && num < 80000) {
      // Excel 1900 date system
      const date = new Date(Math.round((num - 25569) * 86400 * 1000));
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    }
  }

  const str = String(raw).trim();

  // If already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }

  // Handle DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (dmyMatch) {
    const p1 = parseInt(dmyMatch[1], 10);
    const p2 = parseInt(dmyMatch[2], 10);
    const year = parseInt(dmyMatch[3], 10);

    // If p1 > 12, it's definitely DD/MM/YYYY
    // In India (Ayurvedic context), standard format is DD/MM/YYYY
    let day = p1;
    let month = p2;
    if (p1 <= 12 && p2 > 12) {
      // It's MM/DD/YYYY
      month = p1;
      day = p2;
    }

    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
  }

  // Try standard Date parsing
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().split('T')[0];
  }

  return null;
}

/**
 * Calculates calendar day difference between expiry date and today in Asia/Kolkata timezone.
 * Returns:
 * diffDays:
 *  < 0 : EXPIRED (e.g. -5 means expired 5 days ago)
 *  === 0 : EXPIRES TODAY
 *  > 0 : Days remaining (e.g. 7 means 7 days left)
 */
export function calculateDaysDiff(expiryDateStr: string, todayStr?: string): number {
  const normalizedExpiry = normalizeDateString(expiryDateStr);
  if (!normalizedExpiry) return NaN;

  const today = todayStr || getTodayKolkataString();
  const expiryMidnight = parseDateOnlyToMidnightUTC(normalizedExpiry);
  const todayMidnight = parseDateOnlyToMidnightUTC(today);

  const msPerDay = 1000 * 60 * 60 * 24;
  return Math.round((expiryMidnight - todayMidnight) / msPerDay);
}

/**
 * Main business logic calculator for a medicine batch according to MERS requirements:
 * - EXPIRED: Expiry date is before today's calendar date (diffDays < 0).
 * - EXPIRING SOON: Expiry date is today or within the next 7 calendar days (0 <= diffDays <= thresholdDays).
 * - SAFE: Expiry date is more than 7 calendar days away (diffDays > thresholdDays).
 */
export function calculateMedicineStatus(
  medicine: Medicine,
  thresholdDays: number = 7,
  todayStr?: string
): CalculatedMedicine {
  const today = todayStr || getTodayKolkataString();
  const diffDays = calculateDaysDiff(medicine.expiryDate, today);

  let status: ExpiryStatus = 'SAFE';
  let daysRemaining = 0;
  let daysPastExpiry = 0;
  let isToday = false;
  let statusLabel = 'Safe';

  if (isNaN(diffDays)) {
    status = 'EXPIRED';
    statusLabel = 'Invalid Expiry';
  } else if (diffDays < 0) {
    status = 'EXPIRED';
    daysPastExpiry = Math.abs(diffDays);
    daysRemaining = 0;
    statusLabel = `Expired (${daysPastExpiry} ${daysPastExpiry === 1 ? 'day' : 'days'} ago)`;
  } else if (diffDays <= thresholdDays) {
    status = 'EXPIRING_SOON';
    daysRemaining = diffDays;
    isToday = diffDays === 0;
    if (isToday) {
      statusLabel = 'Expires Today';
    } else {
      statusLabel = `Expiring Soon (${daysRemaining} ${daysRemaining === 1 ? 'day' : 'days'} left)`;
    }
  } else {
    status = 'SAFE';
    daysRemaining = diffDays;
    statusLabel = `Safe (${daysRemaining} days remaining)`;
  }

  return {
    ...medicine,
    status,
    daysRemaining,
    daysPastExpiry,
    isToday,
    statusLabel,
  };
}

/**
 * Determines whether this batch triggers an expiry alert based on settings:
 * Alerts for:
 * - 7 days before expiry
 * - 3 days before expiry
 * - 1 day before expiry
 * - The expiry date (0 days)
 * - Already-expired medicine batches (< 0 days)
 */
export function getAlertTypesForMedicine(
  diffDays: number,
  settings?: HospitalSettings
): { alertType: AlertType; message: string } | null {
  if (isNaN(diffDays)) return null;

  const notifyExpired = settings ? settings.notifyExpired !== false : true;
  const notifyDayOf = settings ? settings.notifyDayOf !== false : true;
  const notify1Day = settings ? settings.notify1Day !== false : true;
  const notify3Days = settings ? settings.notify3Days !== false : true;
  const notify7Days = settings ? settings.notify7Days !== false : true;

  if (diffDays < 0 && notifyExpired) {
    const daysAgo = Math.abs(diffDays);
    return {
      alertType: 'expired',
      message: `Batch is EXPIRED (${daysAgo} ${daysAgo === 1 ? 'day' : 'days'} ago). Action required: quarantine or safely dispose.`,
    };
  }

  if (diffDays === 0 && notifyDayOf) {
    return {
      alertType: 'expires_today',
      message: 'Batch expires TODAY. Must be used or removed from active dispensing.',
    };
  }

  if (diffDays === 1 && notify1Day) {
    return {
      alertType: 'expires_1_day',
      message: 'Batch expires in 1 DAY (Tomorrow). Prioritize dispensing immediately.',
    };
  }

  if (diffDays === 3 && notify3Days) {
    return {
      alertType: 'expires_3_days',
      message: 'Batch expires in 3 DAYS. Check inventory for alternate batches.',
    };
  }

  if (diffDays === 7 && notify7Days) {
    return {
      alertType: 'expires_7_days',
      message: 'Batch expires in 7 DAYS. Upcoming expiry alert.',
    };
  }

  // Also catch other expiring-soon days (e.g. 2, 4, 5, 6) if threshold is configured
  const threshold = settings?.expiringSoonThresholdDays ?? 7;
  if (diffDays > 0 && diffDays <= threshold) {
    return {
      alertType: 'expiring_soon',
      message: `Batch is expiring in ${diffDays} days.`,
    };
  }

  return null;
}
