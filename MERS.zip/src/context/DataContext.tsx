import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  db,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import { useAuth } from './AuthContext';
import {
  Medicine,
  CalculatedMedicine,
  ExpiryNotification,
  HospitalSettings,
  ActivityLog,
  DashboardStats,
} from '../types';
import {
  calculateMedicineStatus,
  calculateDaysDiff,
  getAlertTypesForMedicine,
  getTodayKolkataString,
} from '../utils/expiry';
import { getSampleMedicines } from '../utils/sampleData';

const DEFAULT_SETTINGS: HospitalSettings = {
  hospitalName: 'Ayurvedic Hospital & Research Centre',
  expiringSoonThresholdDays: 7,
  lowStockThreshold: 10,
  timezone: 'Asia/Kolkata',
  notifyExpired: true,
  notify7Days: true,
  notify3Days: true,
  notify1Day: true,
  notifyDayOf: true,
};

interface DataContextType {
  medicines: CalculatedMedicine[];
  rawMedicines: Medicine[];
  notifications: ExpiryNotification[];
  settings: HospitalSettings;
  activityLogs: ActivityLog[];
  stats: DashboardStats;
  loading: boolean;
  addMedicine: (medicine: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>) => Promise<string>;
  updateMedicine: (id: string, medicine: Partial<Medicine>) => Promise<void>;
  deleteMedicine: (id: string) => Promise<void>;
  bulkAddMedicines: (medicinesList: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>[]) => Promise<{ added: number; skipped: number }>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  updateSettings: (newSettings: Partial<HospitalSettings>) => Promise<void>;
  runExpiryCheck: () => Promise<{ generated: number; skipped: number }>;
  loadSampleData: () => Promise<number>;
  clearSampleData: () => Promise<number>;
  logActivity: (action: string, details: string) => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [rawMedicines, setRawMedicines] = useState<Medicine[]>([]);
  const [notifications, setNotifications] = useState<ExpiryNotification[]>([]);
  const [settings, setSettings] = useState<HospitalSettings>(DEFAULT_SETTINGS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync Hospital Settings
  useEffect(() => {
    if (!currentUser) return;
    const settingsDocRef = doc(db, 'hospitalSettings', 'general');
    const unsub = onSnapshot(
      settingsDocRef,
      (snapshot) => {
        if (snapshot.exists()) {
          setSettings({ ...DEFAULT_SETTINGS, ...snapshot.data() } as HospitalSettings);
        } else {
          // Initialize default settings document
          setDoc(settingsDocRef, {
            ...DEFAULT_SETTINGS,
            updatedAt: new Date().toISOString(),
            updatedBy: currentUser.uid,
          }).catch(console.error);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'hospitalSettings/general');
      }
    );
    return () => unsub();
  }, [currentUser]);

  // Sync Medicines
  useEffect(() => {
    if (!currentUser) {
      setRawMedicines([]);
      setLoading(false);
      return;
    }

    const medicinesCol = collection(db, 'medicines');
    const unsub = onSnapshot(
      medicinesCol,
      (snapshot) => {
        const list: Medicine[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as Medicine);
        });
        setRawMedicines(list);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'medicines');
        setLoading(false);
      }
    );

    return () => unsub();
  }, [currentUser]);

  // Sync Notifications
  useEffect(() => {
    if (!currentUser) {
      setNotifications([]);
      return;
    }

    const notifCol = collection(db, 'notifications');
    const unsub = onSnapshot(
      notifCol,
      (snapshot) => {
        const list: ExpiryNotification[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as ExpiryNotification);
        });
        // Sort descending by creation date
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setNotifications(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'notifications');
      }
    );

    return () => unsub();
  }, [currentUser]);

  // Sync Activity Logs
  useEffect(() => {
    if (!currentUser) {
      setActivityLogs([]);
      return;
    }

    const logsQuery = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'), limit(50));
    const unsub = onSnapshot(
      logsQuery,
      (snapshot) => {
        const list: ActivityLog[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as ActivityLog);
        });
        setActivityLogs(list);
      },
      (error) => {
        // Fallback without orderBy if index is building
        handleFirestoreError(error, OperationType.GET, 'activityLogs');
      }
    );

    return () => unsub();
  }, [currentUser]);

  // Calculate medicine statuses dynamically with current settings
  const medicines = useMemo(() => {
    const threshold = settings.expiringSoonThresholdDays || 7;
    return rawMedicines
      .map((m) => calculateMedicineStatus(m, threshold))
      .sort((a, b) => {
        // Sort by expiry date ascending (earliest expiry first)
        const diff = a.daysRemaining - b.daysRemaining;
        if (diff !== 0) return diff;
        return a.name.localeCompare(b.name);
      });
  }, [rawMedicines, settings.expiringSoonThresholdDays]);

  // Calculate dashboard statistics
  const stats: DashboardStats = useMemo(() => {
    let safeCount = 0;
    let expiringSoonCount = 0;
    let expiredCount = 0;
    let lowStockCount = 0;
    let totalQuantity = 0;

    const lowStockLimit = settings.lowStockThreshold || 10;

    medicines.forEach((m) => {
      if (m.status === 'SAFE') safeCount++;
      else if (m.status === 'EXPIRING_SOON') expiringSoonCount++;
      else if (m.status === 'EXPIRED') expiredCount++;

      if (m.quantity <= lowStockLimit) lowStockCount++;
      totalQuantity += m.quantity;
    });

    const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

    return {
      totalBatches: medicines.length,
      safeCount,
      expiringSoonCount,
      expiredCount,
      lowStockCount,
      totalQuantity,
      unreadNotificationsCount,
    };
  }, [medicines, notifications, settings.lowStockThreshold]);

  const logActivity = async (action: string, details: string) => {
    if (!currentUser) return;
    try {
      const logId = `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await setDoc(doc(db, 'activityLogs', logId), {
        id: logId,
        action,
        details,
        userId: currentUser.uid,
        userEmail: currentUser.email || 'unknown',
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Could not write activity log:', err);
    }
  };

  const addMedicine = async (medicineData: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
    if (!currentUser) throw new Error('Authentication required');

    // Check duplicate batch number
    const duplicate = rawMedicines.find(
      (m) => m.batchNumber.trim().toLowerCase() === medicineData.batchNumber.trim().toLowerCase()
    );
    if (duplicate) {
      throw new Error(`A medicine batch with number "${medicineData.batchNumber}" already exists (${duplicate.name}).`);
    }

    const id = `med_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const docData: Medicine = {
      ...medicineData,
      id,
      createdBy: currentUser.uid,
      createdAt: now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'medicines', id), docData);
      await logActivity('MEDICINE_CREATED', `Added new batch "${medicineData.name}" (${medicineData.batchNumber})`);
      // Trigger instant expiry check for this batch
      setTimeout(() => runExpiryCheck(), 500);
      return id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `medicines/${id}`);
      throw error;
    }
  };

  const updateMedicine = async (id: string, medicineData: Partial<Medicine>): Promise<void> => {
    if (!currentUser) throw new Error('Authentication required');
    const now = new Date().toISOString();
    const updatePayload = {
      ...medicineData,
      updatedAt: now,
    };

    try {
      await updateDoc(doc(db, 'medicines', id), updatePayload);
      await logActivity('MEDICINE_UPDATED', `Updated batch details for ${medicineData.name || id}`);
      setTimeout(() => runExpiryCheck(), 500);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `medicines/${id}`);
      throw error;
    }
  };

  const deleteMedicine = async (id: string): Promise<void> => {
    if (!currentUser) throw new Error('Authentication required');
    const target = rawMedicines.find((m) => m.id === id);

    try {
      await deleteDoc(doc(db, 'medicines', id));
      await logActivity('MEDICINE_DELETED', `Deleted batch "${target?.name || id}" (${target?.batchNumber || ''})`);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `medicines/${id}`);
      throw error;
    }
  };

  const bulkAddMedicines = async (
    medicinesList: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>[]
  ): Promise<{ added: number; skipped: number }> => {
    if (!currentUser) throw new Error('Authentication required');

    let added = 0;
    let skipped = 0;
    const existingBatches = new Set(rawMedicines.map((m) => m.batchNumber.trim().toLowerCase()));

    for (const item of medicinesList) {
      const batchKey = item.batchNumber.trim().toLowerCase();
      if (existingBatches.has(batchKey)) {
        skipped++;
        continue;
      }

      existingBatches.add(batchKey);
      const id = `med_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const now = new Date().toISOString();
      const docData: Medicine = {
        ...item,
        id,
        createdBy: currentUser.uid,
        createdAt: now,
        updatedAt: now,
      };

      try {
        await setDoc(doc(db, 'medicines', id), docData);
        added++;
      } catch (err) {
        console.error('Failed to import row:', item, err);
        skipped++;
      }
    }

    await logActivity('FILE_IMPORTED', `Imported ${added} medicine batches (${skipped} duplicate/invalid skipped)`);
    setTimeout(() => runExpiryCheck(), 1000);
    return { added, skipped };
  };

  const markNotificationRead = async (id: string): Promise<void> => {
    if (!currentUser) return;
    try {
      await updateDoc(doc(db, 'notifications', id), { isRead: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `notifications/${id}`);
    }
  };

  const markAllNotificationsRead = async (): Promise<void> => {
    if (!currentUser) return;
    const unread = notifications.filter((n) => !n.isRead);
    for (const n of unread) {
      try {
        await updateDoc(doc(db, 'notifications', n.id), { isRead: true });
      } catch (err) {
        console.error('Error marking read:', n.id, err);
      }
    }
  };

  const deleteNotification = async (id: string): Promise<void> => {
    if (!currentUser) return;
    try {
      await deleteDoc(doc(db, 'notifications', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `notifications/${id}`);
    }
  };

  const updateSettings = async (newSettings: Partial<HospitalSettings>): Promise<void> => {
    if (!currentUser) throw new Error('Authentication required');
    const updated = {
      ...settings,
      ...newSettings,
      updatedAt: new Date().toISOString(),
      updatedBy: currentUser.uid,
    };

    try {
      await setDoc(doc(db, 'hospitalSettings', 'general'), updated);
      setSettings(updated);
      await logActivity('SETTINGS_UPDATED', `Updated hospital settings (Threshold: ${updated.expiringSoonThresholdDays} days)`);
      setTimeout(() => runExpiryCheck(), 500);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'hospitalSettings/general');
      throw error;
    }
  };

  /**
   * Evaluates all current medicines against expiry rules and generates persistent notifications.
   * Avoids duplicate notifications via deterministic dedupKey.
   */
  const runExpiryCheck = async (): Promise<{ generated: number; skipped: number }> => {
    if (!currentUser || rawMedicines.length === 0) return { generated: 0, skipped: 0 };

    const todayStr = getTodayKolkataString();
    let generated = 0;
    let skipped = 0;

    const existingKeys = new Set(notifications.map((n) => n.dedupKey));

    for (const med of rawMedicines) {
      const diffDays = calculateDaysDiff(med.expiryDate, todayStr);
      const alert = getAlertTypesForMedicine(diffDays, settings);

      if (alert) {
        // Deterministic deduplication key based on batch number, alert type, and expiry date
        const dedupKey = `${med.batchNumber.trim()}_${alert.alertType}_${med.expiryDate}`;

        if (existingKeys.has(dedupKey)) {
          skipped++;
          continue;
        }

        existingKeys.add(dedupKey);
        const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const notif: ExpiryNotification = {
          id: notifId,
          medicineId: med.id,
          medicineName: med.name,
          batchNumber: med.batchNumber,
          quantity: med.quantity,
          expiryDate: med.expiryDate,
          alertType: alert.alertType,
          daysDiff: diffDays,
          message: `${med.name} (Batch: ${med.batchNumber}): ${alert.message}`,
          isRead: false,
          dedupKey,
          createdAt: new Date().toISOString(),
        };

        try {
          await setDoc(doc(db, 'notifications', notifId), notif);
          generated++;
        } catch (err) {
          console.error('Failed to create notification doc:', notifId, err);
        }
      }
    }

    if (generated > 0) {
      await logActivity('EXPIRY_CHECK_RUN', `Generated ${generated} new persistent expiry alerts (${skipped} already notified)`);
    }

    return { generated, skipped };
  };

  const loadSampleData = async (): Promise<number> => {
    if (!currentUser) throw new Error('Authentication required');
    const samples = getSampleMedicines();
    let loaded = 0;

    for (const sample of samples) {
      // Remove any existing sample batch with same number first
      const existing = rawMedicines.find((m) => m.batchNumber === sample.batchNumber);
      if (existing) {
        await deleteDoc(doc(db, 'medicines', existing.id));
      }

      const id = `sample_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const now = new Date().toISOString();
      await setDoc(doc(db, 'medicines', id), {
        ...sample,
        id,
        createdBy: currentUser.uid,
        createdAt: now,
        updatedAt: now,
      });
      loaded++;
    }

    await logActivity('SAMPLE_DATA_LOADED', `Loaded ${loaded} Ayurvedic sample demonstration medicine batches`);
    setTimeout(() => runExpiryCheck(), 1000);
    return loaded;
  };

  const clearSampleData = async (): Promise<number> => {
    if (!currentUser) throw new Error('Authentication required');
    const sampleMeds = rawMedicines.filter((m) => m.isSample);
    let removed = 0;

    for (const med of sampleMeds) {
      await deleteDoc(doc(db, 'medicines', med.id));
      removed++;
    }

    // Also remove sample notifications
    const sampleNotifs = notifications.filter((n) => n.batchNumber.startsWith('SAMPLE-'));
    for (const notif of sampleNotifs) {
      await deleteDoc(doc(db, 'notifications', notif.id));
    }

    await logActivity('SAMPLE_DATA_CLEARED', `Removed ${removed} sample demonstration records`);
    return removed;
  };

  return (
    <DataContext.Provider
      value={{
        medicines,
        rawMedicines,
        notifications,
        settings,
        activityLogs,
        stats,
        loading,
        addMedicine,
        updateMedicine,
        deleteMedicine,
        bulkAddMedicines,
        markNotificationRead,
        markAllNotificationsRead,
        deleteNotification,
        updateSettings,
        runExpiryCheck,
        loadSampleData,
        clearSampleData,
        logActivity,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
