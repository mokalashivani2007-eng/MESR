export type ExpiryStatus = 'SAFE' | 'EXPIRING_SOON' | 'EXPIRED';

export type AlertType =
  | 'expired'
  | 'expires_today'
  | 'expires_1_day'
  | 'expires_3_days'
  | 'expires_7_days'
  | 'expiring_soon';

export interface Medicine {
  id: string;
  name: string;
  batchNumber: string;
  quantity: number;
  unit?: string;
  category?: string;
  manufacturingDate?: string;
  expiryDate: string; // YYYY-MM-DD
  supplier?: string;
  supplierContact?: string;
  storageLocation?: string;
  description?: string;
  notes?: string;
  isSample?: boolean;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CalculatedMedicine extends Medicine {
  status: ExpiryStatus;
  daysRemaining: number;
  daysPastExpiry: number;
  isToday: boolean;
  statusLabel: string;
}

export interface ExpiryNotification {
  id: string;
  medicineId: string;
  medicineName: string;
  batchNumber: string;
  quantity: number;
  expiryDate: string;
  alertType: AlertType;
  daysDiff: number;
  message: string;
  isRead: boolean;
  dedupKey: string;
  createdAt: string;
}

export interface HospitalSettings {
  id?: string;
  hospitalName: string;
  expiringSoonThresholdDays: number;
  lowStockThreshold: number;
  timezone: string;
  notifyExpired: boolean;
  notify7Days: boolean;
  notify3Days: boolean;
  notify1Day: boolean;
  notifyDayOf: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: 'staff' | 'pharmacist' | 'admin';
  department?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  details: string;
  userId: string;
  userEmail: string;
  timestamp: string;
}

export interface ImportPreviewRow {
  index: number;
  originalData: Record<string, any>;
  mapped: {
    name: string;
    batchNumber: string;
    quantity: number;
    expiryDate: string;
    category?: string;
    unit?: string;
    manufacturingDate?: string;
    supplier?: string;
    supplierContact?: string;
    storageLocation?: string;
    notes?: string;
  };
  errors: string[];
  warnings: string[];
  isValid: boolean;
  isDuplicate?: boolean;
}

export interface DashboardStats {
  totalBatches: number;
  safeCount: number;
  expiringSoonCount: number;
  expiredCount: number;
  lowStockCount: number;
  totalQuantity: number;
  unreadNotificationsCount: number;
}
