import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';
import { testConnection } from './firebase';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MedicineModal } from './components/MedicineModal';
import { MedicineDetailModal } from './components/MedicineDetailModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { NotificationModal } from './components/NotificationModal';
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { InventoryView } from './views/InventoryView';
import { UploadView } from './views/UploadView';
import { AlertsView } from './views/AlertsView';
import { NotificationsView } from './views/NotificationsView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';
import { CalculatedMedicine } from './types';
import { Leaf, Menu } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentUser, loading } = useAuth();
  const { medicines, deleteMedicine } = useData();

  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<CalculatedMedicine | null>(null);
  const [selectedMedicine, setSelectedMedicine] = useState<CalculatedMedicine | null>(null);
  const [deletingMedicine, setDeletingMedicine] = useState<CalculatedMedicine | null>(null);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);

  useEffect(() => {
    testConnection();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFBF8] flex flex-col items-center justify-center p-4">
        <div className="w-14 h-14 rounded-2xl bg-[#164B35] text-white flex items-center justify-center mb-4 shadow-lg animate-pulse">
          <Leaf className="w-8 h-8 text-[#DCEBDD]" />
        </div>
        <h2 className="text-xl font-black text-[#164B35]">MERS</h2>
        <p className="text-xs text-[#247A50] font-semibold mt-1">Medicine Expiry Reminder System</p>
        <p className="text-xs text-gray-400 mt-3">Connecting to Cloud Firestore...</p>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginView />;
  }

  const getPageTitle = () => {
    switch (currentView) {
      case 'dashboard':
        return 'Hospital Dispensary Dashboard';
      case 'inventory':
        return 'Medicine Batch Inventory';
      case 'upload':
        return 'Upload Medicine File';
      case 'alerts':
        return 'Expiry Alerts & Review';
      case 'notifications':
        return 'Notification Center';
      case 'reports':
        return 'Medicine Expiry Reports';
      case 'settings':
        return 'System & Hospital Settings';
      default:
        return 'Dashboard';
    }
  };

  const handleOpenDetailById = (medicineId: string) => {
    const target = medicines.find((m) => m.id === medicineId);
    if (target) {
      setSelectedMedicine(target);
    } else {
      setCurrentView('inventory');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFBF8] flex">
      {/* Sidebar */}
      <Sidebar
        currentView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
        onOpenAddModal={() => {
          setEditingMedicine(null);
          setIsAddModalOpen(true);
        }}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        {/* Top Header */}
        <div className="flex items-center">
          <button
            onClick={() => setMobileSidebarOpen(true)}
            className="p-3 text-[#164B35] hover:bg-gray-100 lg:hidden cursor-pointer"
            title="Toggle Menu"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <Header
              pageTitle={getPageTitle()}
              onOpenNotifications={() => setIsNotificationModalOpen(true)}
              onNavigate={(view) => setCurrentView(view)}
            />
          </div>
        </div>

        {/* View Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentView === 'dashboard' && (
            <DashboardView
              onNavigate={(view) => setCurrentView(view)}
              onOpenAddModal={() => {
                setEditingMedicine(null);
                setIsAddModalOpen(true);
              }}
              onSelectMedicine={(med) => setSelectedMedicine(med)}
            />
          )}

          {currentView === 'inventory' && (
            <InventoryView
              onOpenAddModal={() => {
                setEditingMedicine(null);
                setIsAddModalOpen(true);
              }}
              onOpenEditModal={(med) => {
                setEditingMedicine(med);
                setIsAddModalOpen(true);
              }}
              onSelectMedicine={(med) => setSelectedMedicine(med)}
              onOpenDeleteConfirm={(med) => setDeletingMedicine(med)}
            />
          )}

          {currentView === 'upload' && (
            <UploadView onNavigate={(view) => setCurrentView(view)} />
          )}

          {currentView === 'alerts' && (
            <AlertsView
              onSelectMedicine={(med) => setSelectedMedicine(med)}
              onOpenEditModal={(med) => {
                setEditingMedicine(med);
                setIsAddModalOpen(true);
              }}
              onOpenDeleteConfirm={(med) => setDeletingMedicine(med)}
            />
          )}

          {currentView === 'notifications' && (
            <NotificationsView
              onSelectMedicineById={(id) => handleOpenDetailById(id)}
            />
          )}

          {currentView === 'reports' && <ReportsView />}

          {currentView === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Modals */}
      <MedicineModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingMedicine(null);
        }}
        medicineToEdit={editingMedicine}
      />

      <MedicineDetailModal
        medicine={selectedMedicine}
        isOpen={!!selectedMedicine}
        onClose={() => setSelectedMedicine(null)}
        onEdit={(med) => {
          setSelectedMedicine(null);
          setEditingMedicine(med);
          setIsAddModalOpen(true);
        }}
        onDelete={(med) => {
          setSelectedMedicine(null);
          setDeletingMedicine(med);
        }}
      />

      <DeleteConfirmModal
        medicine={deletingMedicine}
        isOpen={!!deletingMedicine}
        onClose={() => setDeletingMedicine(null)}
        onConfirm={async (id) => {
          await deleteMedicine(id);
        }}
      />

      <NotificationModal
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        onSelectMedicine={(id) => handleOpenDetailById(id)}
        onNavigateToNotifications={() => setCurrentView('notifications')}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <MainLayout />
      </DataProvider>
    </AuthProvider>
  );
}
