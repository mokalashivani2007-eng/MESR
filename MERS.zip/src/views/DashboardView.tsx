import React from 'react';
import {
  Pill,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  PlusCircle,
  FileSpreadsheet,
  Bell,
  ArrowRight,
  TrendingUp,
  Clock,
  Calendar,
  Layers,
  Activity,
  CheckCircle2,
  Package,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { SampleDataBanner } from '../components/SampleDataBanner';
import { CalculatedMedicine } from '../types';

interface DashboardViewProps {
  onNavigate: (view: string) => void;
  onOpenAddModal: () => void;
  onSelectMedicine: (medicine: CalculatedMedicine) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenAddModal,
  onSelectMedicine,
}) => {
  const { medicines, stats, activityLogs, settings } = useData();

  // Upcoming medicines expiring soonest (sorted ascending)
  const upcomingMedicines = medicines
    .filter((m) => m.status === 'EXPIRING_SOON' || m.status === 'EXPIRED')
    .slice(0, 6);

  // Status breakdown percentages
  const total = stats.totalBatches || 1;
  const safePercent = Math.round((stats.safeCount / total) * 100);
  const soonPercent = Math.round((stats.expiringSoonCount / total) * 100);
  const expiredPercent = Math.round((stats.expiredCount / total) * 100);

  return (
    <div className="space-y-6">
      {/* Sample Data Banner */}
      <SampleDataBanner />

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Batches */}
        <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs hover:shadow-sm transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Total Batches
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#FAFBF8] border border-[#DCEBDD] text-[#164B35] flex items-center justify-center">
              <Pill className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-3xl font-black text-[#164B35]">{stats.totalBatches}</div>
            <span className="text-xs text-gray-500 font-medium">
              {stats.totalQuantity.toLocaleString()} total units
            </span>
          </div>
          <div className="mt-2 text-xs text-[#247A50] font-medium flex items-center gap-1">
            <span>In active dispensary inventory</span>
          </div>
        </div>

        {/* Safe Medicines */}
        <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-2xs hover:shadow-sm transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              Safe Medicines
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-3xl font-black text-emerald-700">{stats.safeCount}</div>
            <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
              {safePercent}% of stock
            </span>
          </div>
          <div className="mt-2 text-xs text-gray-500 font-medium">
            Expiry beyond {settings.expiringSoonThresholdDays || 7} days
          </div>
        </div>

        {/* Expiring Soon */}
        <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-2xs hover:shadow-sm transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
              Expiring Soon
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-[#F59E0B] flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-3xl font-black text-[#F59E0B]">{stats.expiringSoonCount}</div>
            <span className="text-xs text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded-full">
              {soonPercent}%
            </span>
          </div>
          <div className="mt-2 text-xs text-amber-700 font-medium flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 shrink-0" />
            <span>Due within {settings.expiringSoonThresholdDays || 7} days</span>
          </div>
        </div>

        {/* Expired Medicines */}
        <div className="bg-white p-5 rounded-2xl border border-red-200 shadow-2xs hover:shadow-sm transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-red-800 uppercase tracking-wider">
              Expired Medicines
            </span>
            <div className="w-9 h-9 rounded-xl bg-red-50 text-[#DC2626] flex items-center justify-center">
              <AlertOctagon className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-3xl font-black text-[#DC2626]">{stats.expiredCount}</div>
            <span className="text-xs text-red-800 font-bold bg-red-50 px-2 py-0.5 rounded-full">
              {expiredPercent}%
            </span>
          </div>
          <div className="mt-2 text-xs text-red-600 font-medium">
            {stats.expiredCount > 0 ? 'Requires immediate disposal' : 'No expired batches'}
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="bg-[#FAFBF8] border border-[#DCEBDD] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-[#164B35] uppercase tracking-wider">
            Quick Actions:
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Medicine</span>
          </button>

          <button
            onClick={() => onNavigate('upload')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#164B35] bg-white border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#247A50]" />
            <span>Upload CSV / Excel</span>
          </button>

          <button
            onClick={() => onNavigate('alerts')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 hover:bg-amber-100 rounded-xl transition cursor-pointer shadow-2xs"
          >
            <AlertTriangle className="w-4 h-4 text-[#F59E0B]" />
            <span>View Expiry Alerts ({stats.expiringSoonCount + stats.expiredCount})</span>
          </button>
        </div>
      </div>

      {/* Grid: Expiry Status Breakdown & Upcoming Expiry Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Expiry Status Chart / Distribution */}
        <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-[#164B35] flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#247A50]" />
                <span>Expiry Status Distribution</span>
              </h2>
              <span className="text-xs text-gray-500 font-medium">
                {stats.totalBatches} batches
              </span>
            </div>

            {/* Visual Progress Bar */}
            <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden flex mb-4 shadow-inner">
              <div
                style={{ width: `${safePercent}%` }}
                className="bg-emerald-500 h-full transition-all duration-500"
                title={`Safe: ${stats.safeCount} (${safePercent}%)`}
              />
              <div
                style={{ width: `${soonPercent}%` }}
                className="bg-[#F59E0B] h-full transition-all duration-500"
                title={`Expiring Soon: ${stats.expiringSoonCount} (${soonPercent}%)`}
              />
              <div
                style={{ width: `${expiredPercent}%` }}
                className="bg-[#DC2626] h-full transition-all duration-500"
                title={`Expired: ${stats.expiredCount} (${expiredPercent}%)`}
              />
            </div>

            {/* Legend & Details */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-50/50 border border-emerald-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
                  <span className="font-semibold text-emerald-900">Safe Medicines</span>
                </div>
                <div className="font-bold text-emerald-800">
                  {stats.safeCount} batches ({safePercent}%)
                </div>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-amber-50/50 border border-amber-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#F59E0B] shrink-0" />
                  <span className="font-semibold text-amber-900">Expiring Soon (≤ {settings.expiringSoonThresholdDays || 7}d)</span>
                </div>
                <div className="font-bold text-amber-800">
                  {stats.expiringSoonCount} batches ({soonPercent}%)
                </div>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-red-50/50 border border-red-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#DC2626] shrink-0" />
                  <span className="font-semibold text-red-900">Expired Batches</span>
                </div>
                <div className="font-bold text-red-800">
                  {stats.expiredCount} batches ({expiredPercent}%)
                </div>
              </div>

              {stats.lowStockCount > 0 && (
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-purple-50/50 border border-purple-100 text-xs">
                  <div className="flex items-center gap-2">
                    <Package className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span className="font-semibold text-purple-900">Low Stock Alert (≤ {settings.lowStockThreshold || 10})</span>
                  </div>
                  <div className="font-bold text-purple-800">
                    {stats.lowStockCount} batches
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-gray-100 text-[11px] text-gray-500 flex items-center justify-between">
            <span>Calculated live via Asia/Kolkata date rules</span>
            <button
              onClick={() => onNavigate('reports')}
              className="text-[#247A50] font-semibold hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              <span>View full reports</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Right Column: Upcoming Expiry Table (2 spans) */}
        <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-[#164B35] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#F59E0B]" />
                  <span>Immediate Expiry Attention Required</span>
                </h2>
                <p className="text-xs text-gray-500 mt-0.5">
                  Batches expiring today, in the next 7 days, or already past expiry
                </p>
              </div>
              <button
                onClick={() => onNavigate('alerts')}
                className="text-xs font-semibold text-[#247A50] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View all alerts</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {upcomingMedicines.length === 0 ? (
              <div className="py-12 text-center text-gray-500 bg-[#FAFBF8] rounded-xl border border-dashed border-[#DCEBDD]">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="text-sm font-semibold text-gray-700">No Urgent Expiry Batches</p>
                <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                  All current Ayurvedic medicines have healthy shelf life beyond the alert threshold.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAFBF8] text-[#164B35] uppercase font-bold border-b border-[#DCEBDD]">
                    <tr>
                      <th className="py-2.5 px-3">Medicine & Batch</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3 text-right">Quantity</th>
                      <th className="py-2.5 px-3">Expiry Date</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {upcomingMedicines.map((m) => {
                      const isExpired = m.status === 'EXPIRED';
                      return (
                        <tr
                          key={m.id}
                          className="hover:bg-[#FAFBF8] transition cursor-pointer"
                          onClick={() => onSelectMedicine(m)}
                        >
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-[#164B35]">{m.name}</div>
                            <div className="text-[11px] text-gray-500 font-mono">
                              Batch: {m.batchNumber}
                              {m.isSample && (
                                <span className="ml-1.5 px-1.5 py-0.2 rounded text-[10px] bg-purple-100 text-purple-700">
                                  Sample
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-gray-600">{m.category || '—'}</td>
                          <td className="py-2.5 px-3 text-right font-semibold">
                            {m.quantity} <span className="text-[10px] text-gray-400 font-normal">{m.unit}</span>
                          </td>
                          <td className="py-2.5 px-3 font-medium text-gray-700">
                            {m.expiryDate}
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold ${
                                isExpired
                                  ? 'bg-red-100 text-[#DC2626]'
                                  : m.isToday
                                  ? 'bg-red-100 text-red-800 animate-pulse'
                                  : 'bg-amber-100 text-[#F59E0B]'
                              }`}
                            >
                              {m.statusLabel}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectMedicine(m);
                              }}
                              className="text-xs font-semibold text-[#247A50] hover:underline cursor-pointer"
                            >
                              Details
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
            <span>Showing up to 6 urgent batches</span>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-[#247A50] font-semibold hover:underline cursor-pointer"
            >
              Browse entire inventory &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Recent Activity Log Feed */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-[#164B35] flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#247A50]" />
            <span>Recent Pharmacy Activity & Audit Trail</span>
          </h2>
          <span className="text-xs text-gray-500">Real-time Firestore audit log</span>
        </div>

        {activityLogs.length === 0 ? (
          <div className="py-6 text-center text-xs text-gray-400">
            No recent activity recorded yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {activityLogs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-[#FAFBF8] border border-[#DCEBDD] text-xs flex flex-col justify-between"
              >
                <div>
                  <div className="font-semibold text-[#164B35] flex items-center justify-between">
                    <span className="truncate max-w-[170px]">{log.action}</span>
                    <span className="text-[10px] text-gray-400 font-normal">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-gray-600 mt-1 text-[11px] leading-relaxed line-clamp-2">
                    {log.details}
                  </p>
                </div>
                <div className="mt-2 text-[10px] text-gray-400 truncate">
                  By: {log.userEmail}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
