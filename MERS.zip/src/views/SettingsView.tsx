import React, { useState, useEffect } from 'react';
import {
  Settings,
  Building2,
  Clock,
  Bell,
  Save,
  Server,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  User,
  ShieldCheck,
  Globe,
  Sliders,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export const SettingsView: React.FC = () => {
  const { currentUser, userProfile, logout } = useAuth();
  const { settings, updateSettings, runExpiryCheck } = useData();

  const [hospitalName, setHospitalName] = useState(settings.hospitalName || '');
  const [thresholdDays, setThresholdDays] = useState(settings.expiringSoonThresholdDays || 7);
  const [lowStockLimit, setLowStockLimit] = useState(settings.lowStockThreshold || 10);
  const [notifyExpired, setNotifyExpired] = useState(settings.notifyExpired !== false);
  const [notify7Days, setNotify7Days] = useState(settings.notify7Days !== false);
  const [notify3Days, setNotify3Days] = useState(settings.notify3Days !== false);
  const [notify1Day, setNotify1Day] = useState(settings.notify1Day !== false);
  const [notifyDayOf, setNotifyDayOf] = useState(settings.notifyDayOf !== false);

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Server scheduler status
  const [serverStatus, setServerStatus] = useState<any>(null);
  const [checkingServer, setCheckingServer] = useState(false);
  const [serverTriggerMessage, setServerTriggerMessage] = useState<string | null>(null);

  useEffect(() => {
    setHospitalName(settings.hospitalName || 'Ayurvedic Hospital & Research Centre');
    setThresholdDays(settings.expiringSoonThresholdDays || 7);
    setLowStockLimit(settings.lowStockThreshold || 10);
    setNotifyExpired(settings.notifyExpired !== false);
    setNotify7Days(settings.notify7Days !== false);
    setNotify3Days(settings.notify3Days !== false);
    setNotify1Day(settings.notify1Day !== false);
    setNotifyDayOf(settings.notifyDayOf !== false);
  }, [settings]);

  // Fetch server-side scheduler status
  const fetchSchedulerStatus = async () => {
    setCheckingServer(true);
    try {
      const res = await fetch('/api/scheduler-status');
      if (res.ok) {
        const data = await res.json();
        setServerStatus(data);
      }
    } catch (err) {
      console.warn('Could not connect to /api/scheduler-status:', err);
    } finally {
      setCheckingServer(false);
    }
  };

  useEffect(() => {
    fetchSchedulerStatus();
  }, []);

  const handleTriggerServerScheduler = async () => {
    setCheckingServer(true);
    setServerTriggerMessage(null);
    try {
      const res = await fetch('/api/trigger-scheduler', { method: 'POST' });
      const data = await res.json();
      setServerTriggerMessage('Server-side background expiry scan triggered successfully.');
      await fetchSchedulerStatus();
      await runExpiryCheck();
      setTimeout(() => setServerTriggerMessage(null), 4000);
    } catch (err: any) {
      setServerTriggerMessage(`Server trigger error: ${err.message}`);
    } finally {
      setCheckingServer(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);
    try {
      await updateSettings({
        hospitalName: hospitalName.trim(),
        expiringSoonThresholdDays: Math.max(1, Math.min(90, Number(thresholdDays))),
        lowStockThreshold: Math.max(0, Number(lowStockLimit)),
        notifyExpired,
        notify7Days,
        notify3Days,
        notify1Day,
        notifyDayOf,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Save settings error:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs">
        <h2 className="text-lg font-bold text-[#164B35] flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#247A50]" />
          <span>Hospital Configuration & System Settings</span>
        </h2>
        <p className="text-xs text-gray-500 mt-0.5">
          Configure hospital profile, alert thresholds, background scheduler parameters, and notification schedules.
        </p>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Hospital Profile Card */}
        <div className="bg-white p-6 rounded-2xl border border-[#DCEBDD] shadow-2xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-gray-100 pb-3">
            <Building2 className="w-5 h-5 text-[#247A50]" />
            <h3 className="text-sm font-bold text-[#164B35]">Hospital Identity</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-gray-700 mb-1">
                Hospital / Institution Name
              </label>
              <input
                type="text"
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                placeholder="e.g. Sri Vaidyanatha Ayurvedic Hospital"
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-gray-700 mb-1">
                System Timezone
              </label>
              <div className="px-3 py-2 text-xs rounded-xl bg-gray-50 border border-gray-200 text-gray-700 font-mono">
                Asia/Kolkata (Indian Standard Time, UTC+05:30)
              </div>
              <p className="text-[10px] text-gray-400 mt-1">
                Fixed to Asia/Kolkata for consistent calendar-day expiry calculations.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-gray-700 mb-1">
                Authorized Staff Department
              </label>
              <div className="px-3 py-2 text-xs rounded-xl bg-gray-50 border border-gray-200 text-gray-700">
                {userProfile?.department || 'Ayurvedic Dispensary & Pharmacy'}
              </div>
            </div>
          </div>
        </div>

        {/* Expiry Thresholds Card */}
        <div className="bg-white p-6 rounded-2xl border border-[#DCEBDD] shadow-2xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-gray-100 pb-3">
            <Sliders className="w-5 h-5 text-[#247A50]" />
            <h3 className="text-sm font-bold text-[#164B35]">Clinical Expiry & Stock Thresholds</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-gray-700 mb-1">
                Expiring-Soon Alert Threshold (Days)
              </label>
              <input
                type="number"
                min="1"
                max="90"
                value={thresholdDays}
                onChange={(e) => setThresholdDays(parseInt(e.target.value, 10) || 7)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
              <p className="text-[10px] text-gray-500 mt-1">
                Batches expiring within this number of calendar days will be flagged as "Expiring Soon" (Default: 7 days).
              </p>
            </div>

            <div>
              <label className="block font-semibold text-gray-700 mb-1">
                Low-Stock Warning Threshold (Units)
              </label>
              <input
                type="number"
                min="0"
                value={lowStockLimit}
                onChange={(e) => setLowStockLimit(parseInt(e.target.value, 10) || 10)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
              <p className="text-[10px] text-gray-500 mt-1">
                Triggers re-order notices when available batch units drop below this number (Default: 10).
              </p>
            </div>
          </div>
        </div>

        {/* Persistent Notification Rules Card */}
        <div className="bg-white p-6 rounded-2xl border border-[#DCEBDD] shadow-2xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-gray-100 pb-3">
            <Bell className="w-5 h-5 text-[#247A50]" />
            <h3 className="text-sm font-bold text-[#164B35]">Notification Delivery Rules</h3>
          </div>

          <p className="text-xs text-gray-600">
            MERS generates persistent Firestore notifications at critical clinical stages. Choose which alerts to generate:
          </p>

          <div className="space-y-3 text-xs">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={notifyExpired}
                onChange={(e) => setNotifyExpired(e.target.checked)}
                className="w-4 h-4 text-[#247A50] rounded border-gray-300 focus:ring-[#247A50]"
              />
              <span className="font-semibold text-gray-800">
                Alert on Expired Medicines (Immediate quarantine reminder)
              </span>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={notifyDayOf}
                onChange={(e) => setNotifyDayOf(e.target.checked)}
                className="w-4 h-4 text-[#247A50] rounded border-gray-300 focus:ring-[#247A50]"
              />
              <span className="font-semibold text-gray-800">
                Alert on Day of Expiry (0 days remaining)
              </span>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={notify1Day}
                onChange={(e) => setNotify1Day(e.target.checked)}
                className="w-4 h-4 text-[#247A50] rounded border-gray-300 focus:ring-[#247A50]"
              />
              <span className="font-semibold text-gray-800">
                Alert 1 Day Prior to Expiry (Tomorrow)
              </span>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={notify3Days}
                onChange={(e) => setNotify3Days(e.target.checked)}
                className="w-4 h-4 text-[#247A50] rounded border-gray-300 focus:ring-[#247A50]"
              />
              <span className="font-semibold text-gray-800">
                Alert 3 Days Prior to Expiry
              </span>
            </label>

            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={notify7Days}
                onChange={(e) => setNotify7Days(e.target.checked)}
                className="w-4 h-4 text-[#247A50] rounded border-gray-300 focus:ring-[#247A50]"
              />
              <span className="font-semibold text-gray-800">
                Alert 7 Days Prior to Expiry
              </span>
            </label>
          </div>

          <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200 text-[11px] text-amber-800">
            <strong>Delivery Mode:</strong> In-app persistent notifications are active. External SMS and Email gateways can be attached to the server scheduler endpoint when external SMS/SMTP provider credentials are configured.
          </div>
        </div>

        {/* Server-Side Background Scheduler Status Panel */}
        <div className="bg-white p-6 rounded-2xl border border-[#DCEBDD] shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <div className="flex items-center space-x-2">
              <Server className="w-5 h-5 text-[#247A50]" />
              <div>
                <h3 className="text-sm font-bold text-[#164B35]">Server-Side Background Expiry Scheduler</h3>
                <p className="text-xs text-gray-500">Autonomous daily backend checks running even when browser is closed</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleTriggerServerScheduler}
              disabled={checkingServer}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#247A50] ${checkingServer ? 'animate-spin' : ''}`} />
              <span>Trigger Server Scan</span>
            </button>
          </div>

          {serverTriggerMessage && (
            <div className="p-2.5 bg-emerald-50 text-emerald-800 text-xs rounded-lg font-medium">
              {serverTriggerMessage}
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-gray-100">
              <div className="text-gray-400">Scheduler State</div>
              <div className="font-bold text-emerald-700 mt-0.5 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
                <span>Active (Server Node.js)</span>
              </div>
            </div>

            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-gray-100">
              <div className="text-gray-400">Last Execution</div>
              <div className="font-bold text-gray-800 mt-0.5">
                {serverStatus?.lastRun ? new Date(serverStatus.lastRun).toLocaleTimeString() : 'Recent'}
              </div>
            </div>

            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-gray-100">
              <div className="text-gray-400">Timezone Engine</div>
              <div className="font-bold text-[#164B35] mt-0.5">
                {serverStatus?.timezone || 'Asia/Kolkata'}
              </div>
            </div>

            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-gray-100">
              <div className="text-gray-400">Executions Completed</div>
              <div className="font-bold text-gray-800 mt-0.5">
                {serverStatus?.executionCount || 1} runs
              </div>
            </div>
          </div>

          {/* Cloud Scheduler Setup Instructions for GCP */}
          <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 text-xs space-y-2">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-[#247A50]" />
              <span>Google Cloud Scheduler Integration (Production Cron Endpoint)</span>
            </div>
            <p className="text-gray-600 text-[11px] leading-relaxed">
              In Google Cloud Platform, you can configure <strong>Cloud Scheduler</strong> to call this application’s dedicated endpoint daily at 00:00 IST:
            </p>
            <div className="p-2 bg-gray-900 text-emerald-400 rounded-lg font-mono text-[11px] overflow-x-auto">
              Target URL: POST https://[YOUR_APP_URL]/api/check-expiry
              <br />
              Schedule: 0 0 * * * (Every midnight in Asia/Kolkata)
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-[#DCEBDD] shadow-2xs">
          {saveSuccess ? (
            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              Settings saved and persisted to Cloud Firestore.
            </span>
          ) : (
            <span className="text-xs text-gray-400">
              Click save to write changes to Firestore.
            </span>
          )}

          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>

      {/* Staff Account Info & Sign Out */}
      <div className="bg-white p-6 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-[#164B35] text-white flex items-center justify-center font-bold text-sm">
            {userProfile?.displayName?.charAt(0) || 'U'}
          </div>
          <div>
            <div className="font-bold text-sm text-[#164B35]">
              {userProfile?.displayName || currentUser?.email}
            </div>
            <div className="text-xs text-gray-500">
              {currentUser?.email} • Role: <strong className="capitalize">{userProfile?.role || 'Staff'}</strong>
            </div>
          </div>
        </div>

        <button
          onClick={() => logout()}
          className="px-4 py-2 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition cursor-pointer"
        >
          Sign Out of MERS
        </button>
      </div>
    </div>
  );
};
