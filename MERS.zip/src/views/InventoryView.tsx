import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  PlusCircle,
  Download,
  Eye,
  Edit2,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  AlertTriangle,
  CheckCircle2,
  AlertOctagon,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { CalculatedMedicine, ExpiryStatus } from '../types';

interface InventoryViewProps {
  onOpenAddModal: () => void;
  onOpenEditModal: (medicine: CalculatedMedicine) => void;
  onSelectMedicine: (medicine: CalculatedMedicine) => void;
  onOpenDeleteConfirm: (medicine: CalculatedMedicine) => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  onOpenAddModal,
  onOpenEditModal,
  onSelectMedicine,
  onOpenDeleteConfirm,
}) => {
  const { medicines, settings } = useData();

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | ExpiryStatus | 'LOW_STOCK'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [sortField, setSortField] = useState<'expiryDate' | 'name' | 'quantity' | 'batchNumber'>('expiryDate');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  // Extract unique categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    medicines.forEach((m) => {
      if (m.category) set.add(m.category);
    });
    return Array.from(set).sort();
  }, [medicines]);

  // Filtered & Sorted medicines
  const filteredMedicines = useMemo(() => {
    return medicines
      .filter((m) => {
        // Search term matches name, batch, supplier, location
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const matchName = m.name.toLowerCase().includes(q);
          const matchBatch = m.batchNumber.toLowerCase().includes(q);
          const matchSupplier = m.supplier?.toLowerCase().includes(q);
          const matchLoc = m.storageLocation?.toLowerCase().includes(q);
          if (!matchName && !matchBatch && !matchSupplier && !matchLoc) return false;
        }

        // Status filter
        if (statusFilter === 'LOW_STOCK') {
          if (m.quantity > (settings.lowStockThreshold || 10)) return false;
        } else if (statusFilter !== 'ALL') {
          if (m.status !== statusFilter) return false;
        }

        // Category filter
        if (categoryFilter !== 'ALL') {
          if (m.category !== categoryFilter) return false;
        }

        return true;
      })
      .sort((a, b) => {
        let valA: any = a[sortField];
        let valB: any = b[sortField];

        if (sortField === 'expiryDate') {
          valA = a.expiryDate;
          valB = b.expiryDate;
        }

        if (typeof valA === 'string') {
          const comp = valA.localeCompare(String(valB));
          return sortOrder === 'asc' ? comp : -comp;
        } else {
          return sortOrder === 'asc' ? valA - valB : valB - valA;
        }
      });
  }, [medicines, searchTerm, statusFilter, categoryFilter, sortField, sortOrder, settings.lowStockThreshold]);

  // Pagination slice
  const totalPages = Math.ceil(filteredMedicines.length / pageSize) || 1;
  const paginatedMedicines = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredMedicines.slice(start, start + pageSize);
  }, [filteredMedicines, currentPage, pageSize]);

  // Export to CSV
  const handleExportCSV = () => {
    if (filteredMedicines.length === 0) return;

    const headers = [
      'Medicine Name',
      'Batch Number',
      'Category',
      'Quantity',
      'Unit',
      'Manufacturing Date',
      'Expiry Date',
      'Days Remaining',
      'Expiry Status',
      'Supplier',
      'Storage Location',
      'Is Demonstration Sample',
    ];

    const rows = filteredMedicines.map((m) => [
      `"${m.name.replace(/"/g, '""')}"`,
      `"${m.batchNumber}"`,
      `"${m.category || ''}"`,
      m.quantity,
      `"${m.unit || ''}"`,
      m.manufacturingDate || '',
      m.expiryDate,
      m.status === 'EXPIRED' ? -m.daysPastExpiry : m.daysRemaining,
      m.status,
      `"${(m.supplier || '').replace(/"/g, '""')}"`,
      `"${(m.storageLocation || '').replace(/"/g, '""')}"`,
      m.isSample ? 'YES' : 'NO',
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MERS_Inventory_Export_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSortToggle = (field: typeof sortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#DCEBDD] shadow-2xs">
        <div>
          <h2 className="text-lg font-bold text-[#164B35]">Medicine Inventory</h2>
          <p className="text-xs text-gray-500">
            Total {medicines.length} batches registered • {filteredMedicines.length} matching current filter
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleExportCSV}
            disabled={filteredMedicines.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer shadow-2xs disabled:opacity-50"
            title="Download CSV report of current filtered inventory"
          >
            <Download className="w-4 h-4 text-[#247A50]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Medicine Batch</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Control Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3.5 rounded-2xl border border-[#DCEBDD] shadow-2xs">
        {/* Search */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search medicine, batch, supplier..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:ring-1 focus:ring-[#247A50] focus:outline-hidden"
          />
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value as any);
              setCurrentPage(1);
            }}
            className="w-full px-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:outline-hidden bg-white"
          >
            <option value="ALL">All Expiry Statuses</option>
            <option value="SAFE">Safe Medicines</option>
            <option value="EXPIRING_SOON">Expiring Soon (≤ {settings.expiringSoonThresholdDays || 7}d)</option>
            <option value="EXPIRED">Expired Batches</option>
            <option value="LOW_STOCK">Low Stock (≤ {settings.lowStockThreshold || 10})</option>
          </select>
        </div>

        {/* Category Filter */}
        <div>
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full px-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:outline-hidden bg-white"
          >
            <option value="ALL">All Categories ({categories.length})</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {/* Sort Field */}
        <div className="flex items-center space-x-2">
          <select
            value={sortField}
            onChange={(e) => setSortField(e.target.value as any)}
            className="flex-1 px-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:outline-hidden bg-white"
          >
            <option value="expiryDate">Sort: Expiry Date</option>
            <option value="name">Sort: Medicine Name</option>
            <option value="quantity">Sort: Quantity</option>
            <option value="batchNumber">Sort: Batch Number</option>
          </select>
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="p-2 rounded-xl border border-gray-200 hover:bg-gray-100 text-[#164B35] transition cursor-pointer"
            title={`Current: ${sortOrder === 'asc' ? 'Ascending' : 'Descending'}`}
          >
            <ArrowUpDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-[#DCEBDD] shadow-2xs overflow-hidden">
        {paginatedMedicines.length === 0 ? (
          <div className="py-16 text-center text-gray-500">
            <Filter className="w-8 h-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-gray-700">No matching medicine batches found</p>
            <p className="text-xs text-gray-400 mt-1">Try adjusting your search criteria or filter tags.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFBF8] text-[#164B35] uppercase font-bold border-b border-[#DCEBDD]">
                <tr>
                  <th className="py-3 px-4">Medicine Name</th>
                  <th className="py-3 px-4">Batch No</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-right">Quantity</th>
                  <th className="py-3 px-4">Mfg Date</th>
                  <th className="py-3 px-4">Expiry Date</th>
                  <th className="py-3 px-4">Days Left</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Storage Location</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {paginatedMedicines.map((m) => {
                  const isExpired = m.status === 'EXPIRED';
                  const isSoon = m.status === 'EXPIRING_SOON';
                  return (
                    <tr
                      key={m.id}
                      className="hover:bg-[#FAFBF8] transition group cursor-pointer"
                      onClick={() => onSelectMedicine(m)}
                    >
                      {/* Name & sample badge */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#164B35] group-hover:text-[#247A50] transition">
                          {m.name}
                        </div>
                        {m.isSample && (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[10px] font-medium bg-purple-100 text-purple-700">
                            <Sparkles className="w-2.5 h-2.5" />
                            Sample Data
                          </span>
                        )}
                      </td>

                      {/* Batch Number */}
                      <td className="py-3 px-4 font-mono font-semibold text-gray-700">
                        {m.batchNumber}
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 text-gray-600">
                        {m.category || '—'}
                      </td>

                      {/* Quantity */}
                      <td className="py-3 px-4 text-right font-bold">
                        <span
                          className={m.quantity <= (settings.lowStockThreshold || 10) ? 'text-purple-700' : 'text-gray-900'}
                        >
                          {m.quantity}
                        </span>{' '}
                        <span className="text-[10px] text-gray-400 font-normal">{m.unit}</span>
                      </td>

                      {/* Mfg Date */}
                      <td className="py-3 px-4 text-gray-500 font-medium">
                        {m.manufacturingDate || '—'}
                      </td>

                      {/* Expiry Date */}
                      <td className="py-3 px-4 font-semibold text-gray-900">
                        {m.expiryDate}
                      </td>

                      {/* Days Remaining / Past */}
                      <td className="py-3 px-4">
                        {isExpired ? (
                          <span className="text-red-700 font-bold">
                            -{m.daysPastExpiry}d
                          </span>
                        ) : (
                          <span
                            className={
                              isSoon ? 'text-amber-800 font-bold' : 'text-emerald-700 font-semibold'
                            }
                          >
                            {m.daysRemaining}d
                          </span>
                        )}
                      </td>

                      {/* Status Badge */}
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            isExpired
                              ? 'bg-red-100 text-[#DC2626]'
                              : isSoon
                              ? 'bg-amber-100 text-[#F59E0B]'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {isExpired ? (
                            <AlertOctagon className="w-3 h-3" />
                          ) : isSoon ? (
                            <AlertTriangle className="w-3 h-3" />
                          ) : (
                            <CheckCircle2 className="w-3 h-3" />
                          )}
                          <span>{m.statusLabel}</span>
                        </span>
                      </td>

                      {/* Storage Location */}
                      <td className="py-3 px-4 text-gray-500">
                        {m.storageLocation || 'Dispensary Shelf'}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => onSelectMedicine(m)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-[#164B35] hover:bg-gray-100 transition cursor-pointer"
                            title="View Details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenEditModal(m)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-[#247A50] hover:bg-[#DCEBDD]/40 transition cursor-pointer"
                            title="Edit Batch"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenDeleteConfirm(m)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-[#DC2626] hover:bg-red-50 transition cursor-pointer"
                            title="Delete Batch"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Bar */}
        <div className="px-4 py-3 bg-[#FAFBF8] border-t border-[#DCEBDD] flex items-center justify-between text-xs text-gray-600">
          <div>
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredMedicines.length)} of {filteredMedicines.length} batches
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-3 py-1 font-semibold text-[#164B35]">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
