import React, { useState, useRef } from 'react';
import {
  FileSpreadsheet,
  Upload,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  Download,
  Trash2,
  RefreshCw,
  FileCheck,
  ArrowRight,
  HelpCircle,
  Edit2,
  Save,
} from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { useData } from '../context/DataContext';
import { normalizeDateString } from '../utils/expiry';
import { ImportPreviewRow, Medicine } from '../types';

export const UploadView: React.FC<{ onNavigate: (view: string) => void }> = ({ onNavigate }) => {
  const { rawMedicines, bulkAddMedicines } = useData();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [previewRows, setPreviewRows] = useState<ImportPreviewRow[]>([]);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);

  // Column mapping state
  const [columnMap, setColumnMap] = useState<Record<string, string>>({
    name: '',
    batchNumber: '',
    quantity: '',
    expiryDate: '',
    category: '',
    unit: '',
    manufacturingDate: '',
    supplier: '',
    storageLocation: '',
  });

  // Import execution state
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    successful: number;
    rejected: number;
    skipped: number;
  } | null>(null);

  // Auto-detect standard column headers
  const autoMapHeaders = (headers: string[]) => {
    const map: Record<string, string> = {
      name: '',
      batchNumber: '',
      quantity: '',
      expiryDate: '',
      category: '',
      unit: '',
      manufacturingDate: '',
      supplier: '',
      storageLocation: '',
    };

    const clean = (h: string) => h.toLowerCase().replace(/[^a-z0-9]/g, '');

    headers.forEach((h) => {
      const c = clean(h);
      if (!map.name && (c.includes('medicinename') || c.includes('drugname') || c === 'name' || c === 'medicine')) {
        map.name = h;
      } else if (!map.batchNumber && (c.includes('batchnumber') || c.includes('batchno') || c === 'batch' || c === 'lot')) {
        map.batchNumber = h;
      } else if (!map.quantity && (c.includes('quantity') || c === 'qty' || c === 'count' || c === 'stock')) {
        map.quantity = h;
      } else if (!map.expiryDate && (c.includes('expiry') || c.includes('expiration') || c.includes('expdate') || c === 'exp')) {
        map.expiryDate = h;
      } else if (!map.category && (c.includes('category') || c.includes('dosage') || c === 'type')) {
        map.category = h;
      } else if (!map.unit && (c.includes('unit') || c === 'pack' || c === 'form')) {
        map.unit = h;
      } else if (!map.manufacturingDate && (c.includes('mfg') || c.includes('manufacturing') || c.includes('mfgdate'))) {
        map.manufacturingDate = h;
      } else if (!map.supplier && (c.includes('supplier') || c.includes('vendor') || c.includes('manufacturer'))) {
        map.supplier = h;
      } else if (!map.storageLocation && (c.includes('location') || c.includes('storage') || c.includes('rack') || c.includes('shelf'))) {
        map.storageLocation = h;
      }
    });

    setColumnMap(map);
    return map;
  };

  // Process rows with column mapping and validation
  const validateRows = (rawRows: Record<string, any>[], mapping: Record<string, string>): ImportPreviewRow[] => {
    const existingBatches = new Set(rawMedicines.map((m) => m.batchNumber.trim().toLowerCase()));
    const fileBatches = new Set<string>();

    return rawRows.map((row, idx) => {
      const name = String(row[mapping.name] || '').trim();
      const batchNumber = String(row[mapping.batchNumber] || '').trim();
      const rawQty = row[mapping.quantity];
      const rawExp = row[mapping.expiryDate];
      const category = String(row[mapping.category] || '').trim();
      const unit = String(row[mapping.unit] || '').trim();
      const rawMfg = row[mapping.manufacturingDate];
      const supplier = String(row[mapping.supplier] || '').trim();
      const storageLocation = String(row[mapping.storageLocation] || '').trim();

      const errors: string[] = [];
      const warnings: string[] = [];

      // Validate Name
      if (!name) {
        errors.push('Missing medicine name.');
      }

      // Validate Batch Number
      if (!batchNumber) {
        errors.push('Missing batch number.');
      } else {
        const lowerBatch = batchNumber.toLowerCase();
        if (fileBatches.has(lowerBatch)) {
          errors.push(`Duplicate batch number in this file (${batchNumber}).`);
        } else {
          fileBatches.add(lowerBatch);
        }

        if (existingBatches.has(lowerBatch)) {
          warnings.push(`Batch "${batchNumber}" already exists in hospital inventory. Will be skipped.`);
        }
      }

      // Validate Quantity
      const qtyNum = parseInt(rawQty, 10);
      if (rawQty === undefined || rawQty === null || rawQty === '' || isNaN(qtyNum) || qtyNum < 0) {
        errors.push(`Invalid quantity: "${rawQty}". Must be a non-negative whole number.`);
      }

      // Validate Expiry Date
      const normalizedExp = normalizeDateString(rawExp);
      if (!rawExp || !normalizedExp) {
        errors.push(`Invalid expiry date: "${rawExp || 'blank'}". Supported: YYYY-MM-DD or DD/MM/YYYY.`);
      }

      // Optional Mfg Date
      let normalizedMfg = undefined;
      if (rawMfg) {
        normalizedMfg = normalizeDateString(rawMfg) || undefined;
      }

      const isValid = errors.length === 0;

      return {
        index: idx,
        originalData: row,
        mapped: {
          name,
          batchNumber,
          quantity: isNaN(qtyNum) ? 0 : qtyNum,
          expiryDate: normalizedExp || String(rawExp || ''),
          category: category || 'Ayurvedic Medicine',
          unit: unit || 'Bottles (450ml)',
          manufacturingDate: normalizedMfg,
          supplier: supplier || undefined,
          storageLocation: storageLocation || undefined,
        },
        errors,
        warnings,
        isValid,
        isDuplicate: warnings.some((w) => w.includes('already exists')),
      };
    });
  };

  // Handle uploaded file
  const handleFileProcess = async (selectedFile: File) => {
    setFile(selectedFile);
    setParsing(true);
    setImportResult(null);

    const ext = selectedFile.name.split('.').pop()?.toLowerCase();

    try {
      if (ext === 'csv') {
        Papa.parse(selectedFile, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            const fields = results.meta.fields || [];
            setRawHeaders(fields);
            const mapping = autoMapHeaders(fields);
            const validated = validateRows(results.data as any[], mapping);
            setPreviewRows(validated);
            setParsing(false);
          },
          error: (err) => {
            alert(`CSV Parse Error: ${err.message}`);
            setParsing(false);
          },
        });
      } else if (ext === 'xlsx' || ext === 'xls') {
        const buffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, { raw: false });

        if (jsonData.length > 0) {
          const fields = Object.keys(jsonData[0]);
          setRawHeaders(fields);
          const mapping = autoMapHeaders(fields);
          const validated = validateRows(jsonData, mapping);
          setPreviewRows(validated);
        } else {
          setPreviewRows([]);
        }
        setParsing(false);
      } else {
        alert('Please upload a valid CSV or Excel (.xlsx, .xls) file.');
        setParsing(false);
      }
    } catch (err: any) {
      alert(`Error reading file: ${err.message}`);
      setParsing(false);
    }
  };

  const handleRemap = (key: string, value: string) => {
    const updated = { ...columnMap, [key]: value };
    setColumnMap(updated);
    const rawRows = previewRows.map((r) => r.originalData);
    const validated = validateRows(rawRows, updated);
    setPreviewRows(validated);
  };

  // In-line editing of invalid rows before import
  const handleSaveInlineEdit = (rowIndex: number, field: string, value: any) => {
    setPreviewRows((prev) => {
      const copy = [...prev];
      const target = { ...copy[rowIndex] };
      (target.mapped as any)[field] = value;

      // Re-validate this row
      const errors: string[] = [];
      const warnings: string[] = [];

      if (!target.mapped.name.trim()) errors.push('Missing medicine name.');
      if (!target.mapped.batchNumber.trim()) errors.push('Missing batch number.');
      if (target.mapped.quantity < 0 || isNaN(target.mapped.quantity)) errors.push('Invalid quantity.');

      const normalizedExp = normalizeDateString(target.mapped.expiryDate);
      if (!normalizedExp) errors.push('Invalid expiry date.');
      else target.mapped.expiryDate = normalizedExp;

      target.errors = errors;
      target.warnings = warnings;
      target.isValid = errors.length === 0;

      copy[rowIndex] = target;
      return copy;
    });
  };

  // Perform Final Import into Firestore
  const handleImportToDatabase = async () => {
    const validRows = previewRows.filter((r) => r.isValid && !r.isDuplicate);
    if (validRows.length === 0) {
      alert('No valid and non-duplicate rows to import.');
      return;
    }

    setImporting(true);
    try {
      const itemsToImport = validRows.map((r) => ({
        name: r.mapped.name,
        batchNumber: r.mapped.batchNumber,
        quantity: r.mapped.quantity,
        unit: r.mapped.unit || 'Bottles (450ml)',
        category: r.mapped.category || 'Ayurvedic Medicine',
        manufacturingDate: r.mapped.manufacturingDate,
        expiryDate: r.mapped.expiryDate,
        supplier: r.mapped.supplier,
        storageLocation: r.mapped.storageLocation,
        isSample: false,
      }));

      const { added, skipped } = await bulkAddMedicines(itemsToImport);

      const rejectedCount = previewRows.filter((r) => !r.isValid).length;
      const totalSkipped = skipped + previewRows.filter((r) => r.isDuplicate).length;

      setImportResult({
        successful: added,
        rejected: rejectedCount,
        skipped: totalSkipped,
      });
    } catch (err: any) {
      alert(`Import failed: ${err.message}`);
    } finally {
      setImporting(false);
    }
  };

  // Download sample CSV template
  const handleDownloadSampleCSV = () => {
    const sampleRows = [
      'Medicine Name,Batch Number,Quantity,Expiry Date,Category,Unit,Manufacturing Date,Supplier,Storage Location',
      'Ashwagandha Churna,ASH-2026-01,50,2026-12-31,Churna,Grams (100g Jar),2025-01-10,Kottakkal Arya Vaidya Sala,Shelf A-01',
      'Brahmi Vati,BRH-2026-09,100,2026-10-25,Vati/Gutika,Tablets,2025-03-15,Dhootapapeshwar,Rack B-03',
      'Dhanwantharam Thailam,DHN-2027-04,30,2027-04-18,Taila,Bottles (450ml),2025-04-01,AVP Coimbatore,Oil Section',
    ].join('\n');

    const blob = new Blob([sampleRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'MERS_Medicine_Import_Template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Download rejected rows with error reasons
  const handleDownloadRejectedCSV = () => {
    const invalidRows = previewRows.filter((r) => !r.isValid);
    if (invalidRows.length === 0) return;

    const headers = ['Row', 'Medicine Name', 'Batch Number', 'Quantity', 'Expiry Date', 'Failure Reasons'];
    const rows = invalidRows.map((r) => [
      r.index + 1,
      `"${r.mapped.name}"`,
      `"${r.mapped.batchNumber}"`,
      r.mapped.quantity,
      `"${r.mapped.expiryDate}"`,
      `"${r.errors.join(' | ')}"`,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'MERS_Rejected_Rows.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const validCount = previewRows.filter((r) => r.isValid && !r.isDuplicate).length;
  const invalidCount = previewRows.filter((r) => !r.isValid).length;
  const duplicateCount = previewRows.filter((r) => r.isDuplicate).length;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#164B35] flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-[#247A50]" />
            <span>Upload Medicine File</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Bulk import medicines from CSV or Excel (.xlsx, .xls) with smart column mapping, row validation, and duplicate prevention.
          </p>
        </div>

        <button
          onClick={handleDownloadSampleCSV}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer self-start md:self-auto shadow-2xs"
        >
          <Download className="w-4 h-4 text-[#247A50]" />
          <span>Download Sample CSV Template</span>
        </button>
      </div>

      {/* Upload Zone */}
      {!file && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleFileProcess(e.dataTransfer.files[0]);
            }
          }}
          className={`border-2 border-dashed rounded-2xl p-10 text-center transition bg-white ${
            isDragging ? 'border-[#247A50] bg-emerald-50/40' : 'border-[#DCEBDD] hover:border-[#247A50]'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileProcess(e.target.files[0]);
              }
            }}
            className="hidden"
          />

          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-[#247A50] flex items-center justify-center mx-auto mb-4 border border-[#DCEBDD]">
            <Upload className="w-8 h-8" />
          </div>

          <h3 className="text-base font-bold text-[#164B35] mb-1">
            Drag & drop your medicine spreadsheet here
          </h3>
          <p className="text-xs text-gray-500 mb-4 max-w-md mx-auto">
            Supports CSV and Excel (.xlsx, .xls). Recognizes headers like Medicine Name, Batch Number, Quantity, and Expiry Date.
          </p>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs"
          >
            <Upload className="w-4 h-4" />
            <span>Browse Files</span>
          </button>
        </div>
      )}

      {/* Post-Import Result Summary Banner */}
      {importResult && (
        <div className="bg-white p-6 rounded-2xl border border-emerald-200 shadow-sm space-y-4 animate-in fade-in">
          <div className="flex items-center space-x-3 text-emerald-800">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <h3 className="text-base font-bold">Import Processing Complete</h3>
              <p className="text-xs text-emerald-700">
                Batch records have been saved directly to Cloud Firestore and inventory has been refreshed.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
              <div className="text-2xl font-black text-emerald-700">{importResult.successful}</div>
              <div className="text-xs font-semibold text-emerald-900 mt-0.5">Successfully Saved</div>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
              <div className="text-2xl font-black text-[#F59E0B]">{importResult.skipped}</div>
              <div className="text-xs font-semibold text-amber-900 mt-0.5">Duplicates Skipped</div>
            </div>
            <div className="p-3 bg-red-50 rounded-xl border border-red-100">
              <div className="text-2xl font-black text-[#DC2626]">{importResult.rejected}</div>
              <div className="text-xs font-semibold text-red-900 mt-0.5">Rejected Rows</div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {importResult.rejected > 0 ? (
              <button
                onClick={handleDownloadRejectedCSV}
                className="text-xs font-semibold text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Rejected Rows with Error Reasons</span>
              </button>
            ) : (
              <span className="text-xs text-gray-500">All evaluated rows cleanly imported!</span>
            )}

            <button
              onClick={() => onNavigate('inventory')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs"
            >
              <span>View In Medicine Inventory</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* File Loaded Preview & Column Mapping Interface */}
      {file && !importResult && (
        <div className="space-y-5">
          {/* File Info Bar */}
          <div className="bg-white p-4 rounded-2xl border border-[#DCEBDD] flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-xl bg-emerald-50 text-[#247A50]">
                <FileCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-sm text-[#164B35]">{file.name}</div>
                <div className="text-xs text-gray-400">
                  {(file.size / 1024).toFixed(1)} KB • {previewRows.length} extracted rows
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setFile(null);
                setPreviewRows([]);
                setRawHeaders([]);
              }}
              className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Cancel & Select Other File</span>
            </button>
          </div>

          {/* Column Mapping Section */}
          <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#164B35]">Spreadsheet Column Mapping</h3>
                <p className="text-xs text-gray-500">
                  Headers detected from your file. Verify that standard fields map correctly.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">
                  Medicine Name <span className="text-red-500">*</span>
                </label>
                <select
                  value={columnMap.name}
                  onChange={(e) => handleRemap('name', e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white"
                >
                  <option value="">Select column...</option>
                  {rawHeaders.map((h) => (
                    <option key={h} value={h}>
                      {h}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">
                  Batch Number <span className="text-red-500">*</span>
                </label>
                <select
                  value={columnMap.batchNumber}
                  onChange={(e) => handleRemap('batchNumber', e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white"
                >
                  <option value="">Select column...</option>
                  {rawHeaders.map((h) => (
                    <option key={h} value={h}>
                      {h}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">
                  Quantity <span className="text-red-500">*</span>
                </label>
                <select
                  value={columnMap.quantity}
                  onChange={(e) => handleRemap('quantity', e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white"
                >
                  <option value="">Select column...</option>
                  {rawHeaders.map((h) => (
                    <option key={h} value={h}>
                      {h}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">
                  Expiry Date <span className="text-red-500">*</span>
                </label>
                <select
                  value={columnMap.expiryDate}
                  onChange={(e) => handleRemap('expiryDate', e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white"
                >
                  <option value="">Select column...</option>
                  {rawHeaders.map((h) => (
                    <option key={h} value={h}>
                      {h}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Validation Counters */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-gray-200">
              <div className="text-xs text-gray-500">Total Rows Extracted</div>
              <div className="text-xl font-black text-gray-900 mt-1">{previewRows.length}</div>
            </div>
            <div className="bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-200">
              <div className="text-xs text-emerald-800 font-semibold">Valid Rows (Ready)</div>
              <div className="text-xl font-black text-emerald-700 mt-1">{validCount}</div>
            </div>
            <div className="bg-amber-50/50 p-3.5 rounded-xl border border-amber-200">
              <div className="text-xs text-amber-800 font-semibold">Existing Duplicates</div>
              <div className="text-xl font-black text-[#F59E0B] mt-1">{duplicateCount}</div>
            </div>
            <div className="bg-red-50/50 p-3.5 rounded-xl border border-red-200">
              <div className="text-xs text-red-800 font-semibold">Invalid Rows</div>
              <div className="text-xl font-black text-[#DC2626] mt-1">{invalidCount}</div>
            </div>
          </div>

          {/* Preview Table */}
          <div className="bg-white rounded-2xl border border-[#DCEBDD] shadow-2xs overflow-hidden">
            <div className="p-4 bg-[#FAFBF8] border-b border-[#DCEBDD] flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#164B35]">Row Validation & Correction Table</h3>
                <p className="text-xs text-gray-500">
                  Staff can edit invalid values directly prior to importing into Firestore.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                {invalidCount > 0 && (
                  <button
                    onClick={handleDownloadRejectedCSV}
                    className="px-3 py-1.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition cursor-pointer"
                  >
                    Download Invalid Rows
                  </button>
                )}
                <button
                  onClick={handleImportToDatabase}
                  disabled={validCount === 0 || importing}
                  className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition disabled:opacity-40 cursor-pointer shadow-xs"
                >
                  {importing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  <span>Confirm & Import ({validCount} Batches)</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto max-h-[420px]">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAFBF8] text-[#164B35] uppercase font-bold sticky top-0 border-b border-[#DCEBDD] z-10">
                  <tr>
                    <th className="py-2.5 px-3">#</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Medicine Name</th>
                    <th className="py-2.5 px-3">Batch Number</th>
                    <th className="py-2.5 px-3 text-right">Quantity</th>
                    <th className="py-2.5 px-3">Expiry Date</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Validation Feedback</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {previewRows.map((row) => {
                    const isEditing = editingRowIndex === row.index;
                    return (
                      <tr
                        key={row.index}
                        className={`hover:bg-[#FAFBF8] ${
                          !row.isValid ? 'bg-red-50/20' : row.isDuplicate ? 'bg-amber-50/20' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 font-mono text-gray-400">{row.index + 1}</td>

                        {/* Status Icon */}
                        <td className="py-2.5 px-3">
                          {!row.isValid ? (
                            <span className="inline-flex items-center gap-1 text-red-600 font-bold text-[11px]">
                              <AlertOctagon className="w-3.5 h-3.5" /> Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span className="inline-flex items-center gap-1 text-amber-600 font-bold text-[11px]">
                              <AlertTriangle className="w-3.5 h-3.5" /> Skip
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-emerald-600 font-bold text-[11px]">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                            </span>
                          )}
                        </td>

                        {/* Medicine Name (editable) */}
                        <td className="py-2.5 px-3 font-semibold text-[#164B35]">
                          {isEditing ? (
                            <input
                              type="text"
                              value={row.mapped.name}
                              onChange={(e) => handleSaveInlineEdit(row.index, 'name', e.target.value)}
                              className="w-full px-2 py-1 text-xs border rounded"
                            />
                          ) : (
                            row.mapped.name || <span className="text-red-400 italic">Empty Name</span>
                          )}
                        </td>

                        {/* Batch Number */}
                        <td className="py-2.5 px-3 font-mono">
                          {isEditing ? (
                            <input
                              type="text"
                              value={row.mapped.batchNumber}
                              onChange={(e) => handleSaveInlineEdit(row.index, 'batchNumber', e.target.value)}
                              className="w-full px-2 py-1 text-xs border rounded"
                            />
                          ) : (
                            row.mapped.batchNumber || <span className="text-red-400 italic">Empty Batch</span>
                          )}
                        </td>

                        {/* Quantity */}
                        <td className="py-2.5 px-3 text-right">
                          {isEditing ? (
                            <input
                              type="number"
                              min="0"
                              value={row.mapped.quantity}
                              onChange={(e) =>
                                handleSaveInlineEdit(row.index, 'quantity', parseInt(e.target.value, 10) || 0)
                              }
                              className="w-16 px-1.5 py-1 text-xs border rounded text-right"
                            />
                          ) : (
                            row.mapped.quantity
                          )}
                        </td>

                        {/* Expiry Date */}
                        <td className="py-2.5 px-3">
                          {isEditing ? (
                            <input
                              type="date"
                              value={row.mapped.expiryDate}
                              onChange={(e) => handleSaveInlineEdit(row.index, 'expiryDate', e.target.value)}
                              className="px-1.5 py-1 text-xs border rounded"
                            />
                          ) : (
                            <span className={!row.isValid && row.errors.some((e) => e.includes('expiry')) ? 'text-red-600 font-bold' : ''}>
                              {row.mapped.expiryDate || <span className="text-red-400 italic">Missing</span>}
                            </span>
                          )}
                        </td>

                        {/* Category */}
                        <td className="py-2.5 px-3 text-gray-500">{row.mapped.category}</td>

                        {/* Errors or Action */}
                        <td className="py-2.5 px-3">
                          <div className="flex items-center justify-between gap-2">
                            <div className="text-[11px]">
                              {row.errors.length > 0 && (
                                <span className="text-red-600 block">{row.errors.join(' ')}</span>
                              )}
                              {row.warnings.length > 0 && (
                                <span className="text-amber-700 block">{row.warnings.join(' ')}</span>
                              )}
                            </div>

                            <button
                              onClick={() => setEditingRowIndex(isEditing ? null : row.index)}
                              className="p-1 text-gray-400 hover:text-[#247A50] shrink-0 cursor-pointer"
                              title="Edit values"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
