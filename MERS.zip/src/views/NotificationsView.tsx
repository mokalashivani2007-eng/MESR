import React, { useState, useMemo } from 'react';
import {
  Bell,
  CheckCheck,
  Calendar,
  AlertTriangle,
  AlertOctagon,
  ExternalLink,
  Trash2,
  Clock,
  CheckCircle2,
  Filter,
  RefreshCw,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { ExpiryNotification } from '../types';

interface NotificationsViewProps {
  onSelectMedicineById: (medicineId: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onSelectMedicineById,
}) => {
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    deleteNotification,
    runExpiryCheck,
  } = useData();

  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'soon' | 'expired'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const expiredCount = notifications.filter((n) => n.alertType === 'expired').length;
  const soonCount = notifications.filter((n) => n.alertType !== 'expired').length;

  const filteredNotifications = useMemo(() => {
    return notifications.filter((n) => {
      // Tab filter
      if (activeTab === 'unread' && n.isRead) return false;
      if (activeTab === 'expired' && n.alertType !== 'expired') return false;
      if (activeTab === 'soon' && n.alertType === 'expired') return false;

      // Search term
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        return (
          n.medicineName.toLowerCase().includes(q) ||
          n.batchNumber.toLowerCase().includes(q) ||
          n.message.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [notifications, activeTab, searchTerm]);

  const handleManualScan = async () => {
    setIsScanning(true);
    setScanResult(null);
    try {
      const res = await runExpiryCheck();
      setScanResult(`Check complete: ${res.generated} new alerts created (${res.skipped} already logged).`);
      setTimeout(() => setScanResult(null), 4000);
    } catch (err: any) {
      setScanResult('Check completed.');
      setTimeout(() => setScanResult(null), 3000);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#164B35] flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#247A50]" />
            <span>Persistent Notification Center</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Real-time and scheduled background expiry notifications stored securely in Cloud Firestore.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {unreadCount > 0 && (
            <button
              onClick={() => markAllNotificationsRead()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer shadow-2xs"
            >
              <CheckCheck className="w-4 h-4 text-[#247A50]" />
              <span>Mark All as Read</span>
            </button>
          )}

          <button
            onClick={handleManualScan}
            disabled={isScanning}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>Scan for Alerts Now</span>
          </button>
        </div>
      </div>

      {scanResult && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{scanResult}</span>
        </div>
      )}

      {/* Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-[#DCEBDD] shadow-2xs text-xs">
        <div className="flex items-center space-x-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'all'
                ? 'bg-[#164B35] text-white shadow-xs'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            All Notifications ({notifications.length})
          </button>

          <button
            onClick={() => setActiveTab('unread')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'unread'
                ? 'bg-[#247A50] text-white shadow-xs'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Unread ({unreadCount})
          </button>

          <button
            onClick={() => setActiveTab('soon')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'soon'
                ? 'bg-[#F59E0B] text-white shadow-xs'
                : 'text-amber-800 hover:bg-amber-50'
            }`}
          >
            Expiring Soon ({soonCount})
          </button>

          <button
            onClick={() => setActiveTab('expired')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'expired'
                ? 'bg-[#DC2626] text-white shadow-xs'
                : 'text-red-800 hover:bg-red-50'
            }`}
          >
            Expired ({expiredCount})
          </button>
        </div>

        <div className="w-full sm:w-64">
          <input
            type="text"
            placeholder="Search notification messages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:outline-hidden"
          />
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-2.5">
        {filteredNotifications.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-2xl border border-[#DCEBDD] text-gray-500">
            <Bell className="w-10 h-10 text-gray-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-gray-700">No notifications found</p>
            <p className="text-xs text-gray-400 mt-1">
              Active alerts are generated 7d, 3d, 1d prior to expiry, on the expiry day, and when expired.
            </p>
          </div>
        ) : (
          filteredNotifications.map((notif) => {
            const isExpired = notif.alertType === 'expired';
            return (
              <div
                key={notif.id}
                className={`p-4 rounded-2xl border transition flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                  notif.isRead
                    ? 'bg-white border-[#DCEBDD] hover:border-[#247A50]'
                    : isExpired
                    ? 'bg-red-50/40 border-red-200'
                    : 'bg-amber-50/40 border-amber-200'
                }`}
              >
                <div className="flex items-start space-x-3.5">
                  <div className="mt-1">
                    {isExpired ? (
                      <div className="w-9 h-9 rounded-xl bg-red-100 text-[#DC2626] flex items-center justify-center shrink-0">
                        <AlertOctagon className="w-5 h-5" />
                      </div>
                    ) : (
                      <div className="w-9 h-9 rounded-xl bg-amber-100 text-[#F59E0B] flex items-center justify-center shrink-0">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-[#164B35]">{notif.medicineName}</h4>
                      <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                        Batch: {notif.batchNumber}
                      </span>
                      {!notif.isRead && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#DC2626] text-white">
                          NEW
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-gray-700 mt-1 leading-relaxed">
                      {notif.message}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-gray-500 mt-2">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-[#247A50]" />
                        Expiry: <strong className="text-gray-800">{notif.expiryDate}</strong>
                      </span>
                      <span>•</span>
                      <span>Stock Quantity: <strong className="text-gray-800">{notif.quantity}</strong></span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-gray-400" />
                        {new Date(notif.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Notification Row Actions */}
                <div className="flex items-center space-x-2 self-end md:self-center shrink-0">
                  <button
                    onClick={() => onSelectMedicineById(notif.medicineId)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#247A50] hover:bg-[#DCEBDD]/40 rounded-lg transition cursor-pointer"
                  >
                    <span>View Record</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  {!notif.isRead && (
                    <button
                      onClick={() => markNotificationRead(notif.id)}
                      className="px-2.5 py-1.5 text-xs text-gray-600 hover:text-gray-900 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition cursor-pointer"
                    >
                      Mark Read
                    </button>
                  )}

                  <button
                    onClick={() => deleteNotification(notif.id)}
                    className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition cursor-pointer"
                    title="Delete Notification"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
