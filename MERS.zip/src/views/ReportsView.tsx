import React, { useState, useMemo } from 'react';
import {
  FileText,
  Printer,
  Download,
  Calendar,
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  Package,
  Layers,
  Filter,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { getTodayKolkataString } from '../utils/expiry';

export const ReportsView: React.FC = () => {
  const { medicines, stats, settings } = useData();

  // Date range filter
  const todayStr = getTodayKolkataString();
  const [startDate, setStartDate] = useState(todayStr);
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split('T')[0];
  });

  const [reportType, setReportType] = useState<'DATE_RANGE' | 'EXPIRED_ALL' | 'LOW_STOCK' | 'FULL_SUMMARY'>('DATE_RANGE');

  // Filtered dataset for the report
  const reportData = useMemo(() => {
    if (reportType === 'EXPIRED_ALL') {
      return medicines.filter((m) => m.status === 'EXPIRED');
    }
    if (reportType === 'LOW_STOCK') {
      return medicines.filter((m) => m.quantity <= (settings.lowStockThreshold || 10));
    }
    if (reportType === 'DATE_RANGE') {
      return medicines.filter((m) => {
        if (!m.expiryDate) return false;
        return m.expiryDate >= startDate && m.expiryDate <= endDate;
      });
    }
    return medicines;
  }, [medicines, reportType, startDate, endDate, settings.lowStockThreshold]);

  // Export CSV
  const handleExportCSV = () => {
    if (reportData.length === 0) return;

    const headers = [
      'Medicine Name',
      'Batch Number',
      'Category',
      'Quantity',
      'Unit',
      'Expiry Date',
      'Days Remaining',
      'Status',
      'Storage Location',
      'Supplier',
    ];

    const rows = reportData.map((m) => [
      `"${m.name.replace(/"/g, '""')}"`,
      `"${m.batchNumber}"`,
      `"${m.category || ''}"`,
      m.quantity,
      `"${m.unit || ''}"`,
      m.expiryDate,
      m.status === 'EXPIRED' ? -m.daysPastExpiry : m.daysRemaining,
      m.status,
      `"${(m.storageLocation || '').replace(/"/g, '""')}"`,
      `"${(m.supplier || '').replace(/"/g, '""')}"`,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MERS_${reportType}_Report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Control Bar (Hidden on print) */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 no-print">
        <div>
          <h2 className="text-lg font-bold text-[#164B35] flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#247A50]" />
            <span>Hospital Pharmacy Expiry Reports</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Audit-ready medicine expiry statements, disposal audit sheets, and re-order forecasts.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportCSV}
            disabled={reportData.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer shadow-2xs disabled:opacity-40"
          >
            <Download className="w-4 h-4 text-[#247A50]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-xl transition cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Filter Controls (Hidden on print) */}
      <div className="bg-white p-4 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex items-center space-x-2 text-xs">
          <span className="font-semibold text-gray-700">Report Focus:</span>
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl border border-gray-200 bg-white font-medium"
          >
            <option value="DATE_RANGE">Expiring Within Date Range</option>
            <option value="EXPIRED_ALL">All Expired Stock (Disposal Sheet)</option>
            <option value="LOW_STOCK">Low Stock Medicines (Re-order Sheet)</option>
            <option value="FULL_SUMMARY">Complete Hospital Inventory Audit</option>
          </select>
        </div>

        {reportType === 'DATE_RANGE' && (
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-gray-500">From:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1 rounded-lg border border-gray-200 text-xs"
            />
            <span className="text-gray-500">To:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1 rounded-lg border border-gray-200 text-xs"
            />
          </div>
        )}
      </div>

      {/* Printable Report Canvas */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#DCEBDD] shadow-sm space-y-6">
        {/* Report Official Header */}
        <div className="border-b border-gray-200 pb-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-2xl font-black text-[#164B35] tracking-tight">
                {settings.hospitalName || 'Ayurvedic Hospital & Research Centre'}
              </div>
              <div className="text-sm font-bold text-[#247A50] mt-0.5">
                MERS — Medicine Expiry Reminder System Audit Report
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Generated: {new Date().toLocaleString()} • Timezone: Asia/Kolkata (IST)
              </div>
            </div>

            <div className="text-right text-xs text-gray-500">
              <div className="font-bold text-[#164B35] uppercase tracking-wider">Audit Scope</div>
              <div className="font-semibold text-gray-800 mt-0.5">
                {reportType === 'DATE_RANGE'
                  ? `Expiring: ${startDate} to ${endDate}`
                  : reportType === 'EXPIRED_ALL'
                  ? 'Expired Quarantine Audit'
                  : reportType === 'LOW_STOCK'
                  ? `Low Stock Inventory (≤ ${settings.lowStockThreshold || 10})`
                  : 'Full Pharmacy Inventory'}
              </div>
            </div>
          </div>
        </div>

        {/* Statistical Summary Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-[#FAFBF8] border border-[#DCEBDD] rounded-xl text-center">
            <div className="text-xs text-gray-500 font-medium">Total In Scope</div>
            <div className="text-2xl font-black text-[#164B35] mt-1">{reportData.length}</div>
            <div className="text-[10px] text-gray-400">Batches</div>
          </div>
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center">
            <div className="text-xs text-emerald-800 font-medium">Safe Count</div>
            <div className="text-2xl font-black text-emerald-700 mt-1">
              {reportData.filter((m) => m.status === 'SAFE').length}
            </div>
            <div className="text-[10px] text-emerald-600">Active Dispensing</div>
          </div>
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-center">
            <div className="text-xs text-amber-800 font-medium">Expiring Soon</div>
            <div className="text-2xl font-black text-[#F59E0B] mt-1">
              {reportData.filter((m) => m.status === 'EXPIRING_SOON').length}
            </div>
            <div className="text-[10px] text-amber-700">Near Expiry Alert</div>
          </div>
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-center">
            <div className="text-xs text-red-800 font-medium">Expired Batches</div>
            <div className="text-2xl font-black text-[#DC2626] mt-1">
              {reportData.filter((m) => m.status === 'EXPIRED').length}
            </div>
            <div className="text-[10px] text-red-600">Quarantine Action</div>
          </div>
        </div>

        {/* Report Records Table */}
        <div className="border border-gray-200 rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAFBF8] text-[#164B35] uppercase font-bold border-b border-gray-200">
              <tr>
                <th className="py-2.5 px-3">#</th>
                <th className="py-2.5 px-3">Medicine Formulation</th>
                <th className="py-2.5 px-3">Batch No</th>
                <th className="py-2.5 px-3 text-right">Quantity</th>
                <th className="py-2.5 px-3">Expiry Date</th>
                <th className="py-2.5 px-3">Days Remaining</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Location</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {reportData.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-gray-500">
                    No medicine batches found matching this report scope.
                  </td>
                </tr>
              ) : (
                reportData.map((m, idx) => (
                  <tr key={m.id}>
                    <td className="py-2 px-3 font-mono text-gray-400">{idx + 1}</td>
                    <td className="py-2 px-3">
                      <div className="font-bold text-gray-900">{m.name}</div>
                      <div className="text-[10px] text-gray-500">{m.category}</div>
                    </td>
                    <td className="py-2 px-3 font-mono font-medium">{m.batchNumber}</td>
                    <td className="py-2 px-3 text-right font-bold">
                      {m.quantity} <span className="text-[10px] font-normal text-gray-500">{m.unit}</span>
                    </td>
                    <td className="py-2 px-3 font-semibold">{m.expiryDate}</td>
                    <td className="py-2 px-3 font-medium">
                      {m.status === 'EXPIRED' ? (
                        <span className="text-red-700 font-bold">Expired (-{m.daysPastExpiry}d)</span>
                      ) : (
                        <span>{m.daysRemaining} days</span>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          m.status === 'EXPIRED'
                            ? 'bg-red-100 text-red-700'
                            : m.status === 'EXPIRING_SOON'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {m.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-gray-600">{m.storageLocation || 'Dispensary Shelf'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Report Footer & Sign-off Block */}
        <div className="pt-8 border-t border-gray-200 grid grid-cols-2 text-xs text-gray-600">
          <div>
            <div className="font-bold text-[#164B35]">Chief Pharmacist Verification</div>
            <div className="mt-8 border-t border-gray-300 w-48 pt-1 text-gray-500">
              Signature & Date
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-[#164B35]">Medical Superintendent / Administrator</div>
            <div className="mt-8 border-t border-gray-300 w-48 ml-auto pt-1 text-gray-500">
              Signature & Date
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
