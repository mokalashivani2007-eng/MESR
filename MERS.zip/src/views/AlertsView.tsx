import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  Search,
  Download,
  Filter,
  ArrowUpDown,
  Calendar,
  Layers,
  Sparkles,
  Eye,
  Trash2,
  Edit2,
  ShieldAlert,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { CalculatedMedicine } from '../types';

interface AlertsViewProps {
  onSelectMedicine: (medicine: CalculatedMedicine) => void;
  onOpenEditModal: (medicine: CalculatedMedicine) => void;
  onOpenDeleteConfirm: (medicine: CalculatedMedicine) => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  onSelectMedicine,
  onOpenEditModal,
  onOpenDeleteConfirm,
}) => {
  const { medicines, settings } = useData();

  const [activeTab, setActiveTab] = useState<'EXPIRED' | 'EXPIRING_SOON' | 'SAFE'>('EXPIRED');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Filter medicines by active tab
  const tabMedicines = useMemo(() => {
    return medicines.filter((m) => m.status === activeTab);
  }, [medicines, activeTab]);

  // Search & sort
  const filteredMedicines = useMemo(() => {
    return tabMedicines
      .filter((m) => {
        if (!searchTerm.trim()) return true;
        const q = searchTerm.toLowerCase();
        return (
          m.name.toLowerCase().includes(q) ||
          m.batchNumber.toLowerCase().includes(q) ||
          m.category?.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        const diff = a.daysRemaining - b.daysRemaining;
        return sortOrder === 'asc' ? diff : -diff;
      });
  }, [tabMedicines, searchTerm, sortOrder]);

  // Counts
  const expiredCount = medicines.filter((m) => m.status === 'EXPIRED').length;
  const expiringSoonCount = medicines.filter((m) => m.status === 'EXPIRING_SOON').length;
  const safeCount = medicines.filter((m) => m.status === 'SAFE').length;

  const handleExportCSV = () => {
    if (filteredMedicines.length === 0) return;

    const headers = [
      'Medicine Name',
      'Batch Number',
      'Quantity',
      'Unit',
      'Category',
      'Expiry Date',
      'Days Remaining / Past',
      'Expiry Status',
      'Storage Location',
    ];

    const rows = filteredMedicines.map((m) => [
      `"${m.name.replace(/"/g, '""')}"`,
      `"${m.batchNumber}"`,
      m.quantity,
      `"${m.unit || ''}"`,
      `"${m.category || ''}"`,
      m.expiryDate,
      m.status === 'EXPIRED' ? -m.daysPastExpiry : m.daysRemaining,
      m.status,
      `"${(m.storageLocation || '').replace(/"/g, '""')}"`,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MERS_Alerts_${activeTab}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#164B35] flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#F59E0B]" />
            <span>Expiry Alerts & Clinical Review</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Identify expired medicines for quarantine, monitor expiring batches, and verify safe inventory.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          disabled={filteredMedicines.length === 0}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#164B35] bg-[#FAFBF8] border border-[#DCEBDD] hover:bg-[#DCEBDD]/40 rounded-xl transition cursor-pointer self-start md:self-auto shadow-2xs disabled:opacity-40"
        >
          <Download className="w-4 h-4 text-[#247A50]" />
          <span>Export {activeTab} CSV</span>
        </button>
      </div>

      {/* 3 Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Expired Tab */}
        <button
          onClick={() => setActiveTab('EXPIRED')}
          className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeTab === 'EXPIRED'
              ? 'bg-red-500 text-white border-red-600 shadow-md font-bold'
              : 'bg-white hover:bg-red-50 text-gray-800 border-red-200'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div
              className={`p-2 rounded-xl ${
                activeTab === 'EXPIRED' ? 'bg-white/20' : 'bg-red-100 text-red-600'
              }`}
            >
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Expired Medicines</div>
              <div
                className={`text-xs ${
                  activeTab === 'EXPIRED' ? 'text-red-100' : 'text-gray-500'
                }`}
              >
                Quarantine & Disposal
              </div>
            </div>
          </div>
          <span
            className={`text-xl font-black px-2.5 py-0.5 rounded-lg ${
              activeTab === 'EXPIRED' ? 'bg-white text-red-600' : 'bg-red-100 text-red-700'
            }`}
          >
            {expiredCount}
          </span>
        </button>

        {/* Expiring Soon Tab */}
        <button
          onClick={() => setActiveTab('EXPIRING_SOON')}
          className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeTab === 'EXPIRING_SOON'
              ? 'bg-[#F59E0B] text-white border-amber-600 shadow-md font-bold'
              : 'bg-white hover:bg-amber-50 text-gray-800 border-amber-200'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div
              className={`p-2 rounded-xl ${
                activeTab === 'EXPIRING_SOON' ? 'bg-white/20' : 'bg-amber-100 text-[#F59E0B]'
              }`}
            >
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Expiring Soon</div>
              <div
                className={`text-xs ${
                  activeTab === 'EXPIRING_SOON' ? 'text-amber-100' : 'text-gray-500'
                }`}
              >
                ≤ {settings.expiringSoonThresholdDays || 7} Days
              </div>
            </div>
          </div>
          <span
            className={`text-xl font-black px-2.5 py-0.5 rounded-lg ${
              activeTab === 'EXPIRING_SOON' ? 'bg-white text-amber-700' : 'bg-amber-100 text-amber-800'
            }`}
          >
            {expiringSoonCount}
          </span>
        </button>

        {/* Safe Tab */}
        <button
          onClick={() => setActiveTab('SAFE')}
          className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeTab === 'SAFE'
              ? 'bg-[#247A50] text-white border-[#164B35] shadow-md font-bold'
              : 'bg-white hover:bg-emerald-50 text-gray-800 border-emerald-200'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div
              className={`p-2 rounded-xl ${
                activeTab === 'SAFE' ? 'bg-white/20' : 'bg-emerald-100 text-emerald-700'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Safe Medicines</div>
              <div
                className={`text-xs ${
                  activeTab === 'SAFE' ? 'text-emerald-100' : 'text-gray-500'
                }`}
              >
                &gt; {settings.expiringSoonThresholdDays || 7} Days
              </div>
            </div>
          </div>
          <span
            className={`text-xl font-black px-2.5 py-0.5 rounded-lg ${
              activeTab === 'SAFE' ? 'bg-white text-[#247A50]' : 'bg-emerald-100 text-emerald-800'
            }`}
          >
            {safeCount}
          </span>
        </button>
      </div>

      {/* Search and Sort Toolbar */}
      <div className="bg-white p-3.5 rounded-2xl border border-[#DCEBDD] shadow-2xs flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder={`Filter ${activeTab.toLowerCase().replace('_', ' ')} medicines...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-gray-200 focus:border-[#247A50] focus:outline-hidden"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="text-gray-500 hidden sm:inline">Sort by Expiry:</span>
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 text-gray-700 font-semibold cursor-pointer"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-[#247A50]" />
            <span>{sortOrder === 'asc' ? 'Earliest First' : 'Latest First'}</span>
          </button>
        </div>
      </div>

      {/* Tab Specific Content Table */}
      <div className="bg-white rounded-2xl border border-[#DCEBDD] shadow-2xs overflow-hidden">
        {filteredMedicines.length === 0 ? (
          <div className="py-16 text-center text-gray-500">
            {activeTab === 'EXPIRED' ? (
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            ) : (
              <Filter className="w-10 h-10 text-gray-300 mx-auto mb-2" />
            )}
            <p className="text-sm font-semibold text-gray-800">
              No {activeTab.toLowerCase().replace('_', ' ')} medicines found.
            </p>
            <p className="text-xs text-gray-400 mt-1">
              {activeTab === 'EXPIRED'
                ? 'Excellent! No medicine batches in your pharmacy are currently expired.'
                : 'No batches match the selected criteria.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFBF8] text-[#164B35] uppercase font-bold border-b border-[#DCEBDD]">
                <tr>
                  <th className="py-3 px-4">Medicine Name</th>
                  <th className="py-3 px-4">Batch Number</th>
                  <th className="py-3 px-4 text-right">Stock Quantity</th>
                  <th className="py-3 px-4">Expiry Date</th>
                  <th className="py-3 px-4">Timeline</th>
                  <th className="py-3 px-4">Status & Recommendation</th>
                  <th className="py-3 px-4">Storage Location</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredMedicines.map((m) => {
                  return (
                    <tr
                      key={m.id}
                      className="hover:bg-[#FAFBF8] transition cursor-pointer"
                      onClick={() => onSelectMedicine(m)}
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#164B35]">{m.name}</div>
                        <div className="text-[11px] text-gray-500">{m.category || 'Ayurvedic formulation'}</div>
                        {m.isSample && (
                          <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[10px] bg-purple-100 text-purple-700 font-medium">
                            Sample
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono font-semibold text-gray-800">
                        {m.batchNumber}
                      </td>

                      <td className="py-3 px-4 text-right font-bold text-gray-900">
                        {m.quantity} <span className="text-[10px] text-gray-400 font-normal">{m.unit}</span>
                      </td>

                      <td className="py-3 px-4 font-semibold text-gray-900">
                        {m.expiryDate}
                      </td>

                      <td className="py-3 px-4 font-bold">
                        {activeTab === 'EXPIRED' ? (
                          <span className="text-[#DC2626]">
                            Expired {m.daysPastExpiry} {m.daysPastExpiry === 1 ? 'day' : 'days'} ago
                          </span>
                        ) : activeTab === 'EXPIRING_SOON' ? (
                          <span className="text-[#F59E0B]">
                            {m.isToday ? 'Expires TODAY' : `${m.daysRemaining} days left`}
                          </span>
                        ) : (
                          <span className="text-[#247A50]">
                            {m.daysRemaining} days left
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        {activeTab === 'EXPIRED' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-100 text-[#DC2626]">
                            <AlertOctagon className="w-3 h-3" /> Quarantine Stock
                          </span>
                        ) : activeTab === 'EXPIRING_SOON' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-[#F59E0B]">
                            <AlertTriangle className="w-3 h-3" /> Prioritize Dispensing
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle2 className="w-3 h-3" /> Safe for Regular Use
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-gray-600">
                        {m.storageLocation || 'Dispensary Shelf'}
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            onClick={() => onSelectMedicine(m)}
                            className="p-1 text-gray-400 hover:text-[#164B35] cursor-pointer"
                            title="View"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenEditModal(m)}
                            className="p-1 text-gray-400 hover:text-[#247A50] cursor-pointer"
                            title="Edit"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenDeleteConfirm(m)}
                            className="p-1 text-gray-400 hover:text-[#DC2626] cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
