import React, { useState } from 'react';
import {
  Leaf,
  ShieldCheck,
  Lock,
  Mail,
  User,
  ArrowRight,
  AlertCircle,
  Calendar,
  CheckCircle2,
  KeyRound,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const LoginView: React.FC = () => {
  const {
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    resetPassword,
    authError,
    clearAuthError,
  } = useAuth();

  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<'staff' | 'pharmacist' | 'admin'>('pharmacist');
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    clearAuthError();
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    clearAuthError();
    try {
      if (mode === 'login') {
        await loginWithEmail(email, password);
      } else if (mode === 'register') {
        await registerWithEmail(email, password, displayName, role);
      } else if (mode === 'reset') {
        await resetPassword(email);
        setResetSent(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFBF8] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Brand Icon */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#164B35] shadow-lg mb-4 border border-[#247A50]">
          <Leaf className="w-8 h-8 text-[#DCEBDD]" />
        </div>

        <h1 className="text-3xl font-extrabold text-[#164B35] tracking-tight">
          MERS
        </h1>
        <p className="text-sm font-semibold text-[#247A50] mt-0.5">
          Medicine Expiry Reminder System
        </p>
        <p className="text-xs text-gray-500 mt-2 max-w-sm mx-auto">
          Ayurvedic Hospital Pharmacy Inventory & Automated Expiry Monitoring
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xl rounded-2xl sm:px-10 border border-[#DCEBDD]">
          {/* Tagline Badge */}
          <div className="mb-6 p-2.5 bg-[#DCEBDD]/40 rounded-xl text-center text-xs font-medium text-[#164B35] border border-[#DCEBDD]">
            Track Medicines • Detect Expiry • Protect Patients
          </div>

          {/* Mode Switcher */}
          {mode !== 'reset' && (
            <div className="flex rounded-lg bg-[#F1F4F1] p-1 mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  clearAuthError();
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                  mode === 'login' ? 'bg-white text-[#164B35] shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  clearAuthError();
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                  mode === 'register' ? 'bg-white text-[#164B35] shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Register Staff
              </button>
            </div>
          )}

          {authError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{authError}</span>
            </div>
          )}

          {resetSent && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>Password reset instructions have been sent to your email.</span>
            </div>
          )}

          {/* Google Sign In Button */}
          {mode !== 'reset' && (
            <div className="mb-6">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full flex items-center justify-center gap-3 px-4 py-2.5 border border-gray-300 rounded-xl shadow-2xs bg-white text-sm font-semibold text-gray-700 hover:bg-gray-50 transition cursor-pointer disabled:opacity-50"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Sign in with Google</span>
              </button>

              <div className="relative my-5">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-400 font-medium">Or continue with email</span>
                </div>
              </div>
            </div>
          )}

          {/* Email / Password Form */}
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-[#164B35] mb-1">
                  Staff Full Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="w-4 h-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Dr. Rajesh Sharma"
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:ring-1 focus:ring-[#247A50] focus:outline-hidden"
                  />
                </div>
              </div>
            )}

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-[#164B35] mb-1">
                  Hospital Role
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
                >
                  <option value="pharmacist">Pharmacist / Dispensary Officer</option>
                  <option value="staff">Hospital Nursing / Clinical Staff</option>
                  <option value="admin">Chief Medical Officer / Admin</option>
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Hospital Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="w-4 h-4 text-gray-400" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="staff@ayurveda-hospital.org"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:ring-1 focus:ring-[#247A50] focus:outline-hidden"
                />
              </div>
            </div>

            {mode !== 'reset' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-[#164B35]">
                    Password
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('reset');
                        clearAuthError();
                      }}
                      className="text-xs text-[#247A50] hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-gray-400" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:ring-1 focus:ring-[#247A50] focus:outline-hidden"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 border border-transparent rounded-xl shadow-xs text-sm font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] focus:outline-hidden transition disabled:opacity-50 cursor-pointer"
            >
              <span>
                {loading
                  ? 'Processing...'
                  : mode === 'login'
                  ? 'Sign In to MERS'
                  : mode === 'register'
                  ? 'Create Staff Account'
                  : 'Send Reset Link'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {mode === 'reset' && (
            <div className="mt-4 text-center">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setResetSent(false);
                  clearAuthError();
                }}
                className="text-xs text-[#247A50] font-semibold hover:underline cursor-pointer"
              >
                &larr; Back to Sign In
              </button>
            </div>
          )}

          {/* Secure Staff Notice */}
          <div className="mt-6 pt-4 border-t border-gray-100 flex items-start space-x-2 text-xs text-gray-500">
            <ShieldCheck className="w-4 h-4 text-[#247A50] shrink-0 mt-0.5" />
            <p>
              Protected by Firebase Authentication & Firestore Security Rules. Access restricted to authorized Ayurvedic hospital personnel.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
