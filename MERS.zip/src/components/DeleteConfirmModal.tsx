import React, { useState } from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { CalculatedMedicine } from '../types';

interface DeleteConfirmModalProps {
  medicine: CalculatedMedicine | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (id: string) => Promise<void>;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  medicine,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [deleting, setDeleting] = useState(false);

  if (!isOpen || !medicine) return null;

  const handleConfirm = async () => {
    setDeleting(true);
    try {
      await onConfirm(medicine.id);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-red-100 overflow-hidden">
        <div className="p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
            <Trash2 className="w-6 h-6" />
          </div>

          <h3 className="text-lg font-bold text-gray-900 mb-1">Delete Medicine Batch?</h3>
          <p className="text-sm text-gray-500 mb-4">
            Are you sure you want to permanently delete the batch{' '}
            <span className="font-semibold text-gray-800">
              "{medicine.name}" (Batch: {medicine.batchNumber})
            </span>{' '}
            from inventory? This action cannot be undone.
          </p>

          <div className="flex items-center justify-center space-x-3">
            <button
              onClick={onClose}
              disabled={deleting}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              disabled={deleting}
              className="px-5 py-2 text-sm font-semibold text-white bg-[#DC2626] rounded-lg hover:bg-red-700 transition disabled:opacity-50 cursor-pointer shadow-xs"
            >
              {deleting ? 'Deleting...' : 'Confirm Delete'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
