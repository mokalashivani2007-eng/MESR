import React from 'react';
import {
  X,
  Pill,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Building2,
  MapPin,
  Edit2,
  Trash2,
  AlertOctagon,
  Phone,
  Tag,
} from 'lucide-react';
import { CalculatedMedicine } from '../types';

interface MedicineDetailModalProps {
  medicine: CalculatedMedicine | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (med: CalculatedMedicine) => void;
  onDelete: (med: CalculatedMedicine) => void;
}

export const MedicineDetailModal: React.FC<MedicineDetailModalProps> = ({
  medicine,
  isOpen,
  onClose,
  onEdit,
  onDelete,
}) => {
  if (!isOpen || !medicine) return null;

  const isExpired = medicine.status === 'EXPIRED';
  const isExpiringSoon = medicine.status === 'EXPIRING_SOON';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-[#DCEBDD] overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 text-white ${
            isExpired ? 'bg-[#DC2626]' : isExpiringSoon ? 'bg-[#F59E0B]' : 'bg-[#164B35]'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-white/20 backdrop-blur-xs">
              <Pill className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold leading-tight">{medicine.name}</h2>
              <div className="text-xs text-white/90">Batch: {medicine.batchNumber}</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Status Banner */}
          <div
            className={`p-4 rounded-xl flex items-center justify-between border ${
              isExpired
                ? 'bg-red-50 border-red-200 text-red-900'
                : isExpiringSoon
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-emerald-50 border-emerald-200 text-emerald-900'
            }`}
          >
            <div className="flex items-center space-x-3">
              {isExpired ? (
                <AlertOctagon className="w-6 h-6 text-red-600 shrink-0" />
              ) : isExpiringSoon ? (
                <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
              ) : (
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
              )}
              <div>
                <div className="font-bold text-sm uppercase tracking-wider">
                  {medicine.statusLabel}
                </div>
                <div className="text-xs opacity-85">
                  {isExpired
                    ? `Expired ${medicine.daysPastExpiry} days ago. Quarantine or dispose immediately.`
                    : isExpiringSoon
                    ? medicine.isToday
                      ? 'Batch expires TODAY. Prioritize dispensing or remove.'
                      : `Expires in ${medicine.daysRemaining} days. Monitor closely.`
                    : `Medicine batch is safe for regular dispensing (${medicine.daysRemaining} days left).`}
                </div>
              </div>
            </div>

            {medicine.isSample && (
              <span className="px-2.5 py-1 text-[11px] font-bold uppercase rounded-md bg-purple-100 text-purple-700 border border-purple-200">
                Sample Data
              </span>
            )}
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-[#DCEBDD]">
              <div className="text-[11px] text-gray-500 font-medium">Quantity in Stock</div>
              <div className="text-lg font-bold text-[#164B35] mt-0.5">
                {medicine.quantity} <span className="text-xs font-normal text-gray-500">{medicine.unit || 'units'}</span>
              </div>
            </div>

            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-[#DCEBDD]">
              <div className="text-[11px] text-gray-500 font-medium">Expiry Date</div>
              <div className="text-base font-bold text-[#164B35] mt-0.5 flex items-center gap-1">
                <Calendar className="w-4 h-4 text-[#247A50]" />
                <span>{medicine.expiryDate}</span>
              </div>
            </div>

            <div className="p-3 bg-[#FAFBF8] rounded-xl border border-[#DCEBDD] col-span-2 sm:col-span-1">
              <div className="text-[11px] text-gray-500 font-medium">Mfg Date</div>
              <div className="text-sm font-semibold text-gray-700 mt-0.5">
                {medicine.manufacturingDate || 'Not specified'}
              </div>
            </div>
          </div>

          {/* Details List */}
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <Tag className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />
              <div>
                <span className="text-xs text-gray-500 block">Dosage Category</span>
                <span className="font-medium text-[#164B35]">{medicine.category || 'General Ayurvedic formulation'}</span>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />
              <div>
                <span className="text-xs text-gray-500 block">Storage Location</span>
                <span className="font-medium text-[#164B35]">{medicine.storageLocation || 'Dispensary Shelf'}</span>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <Building2 className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />
              <div>
                <span className="text-xs text-gray-500 block">Manufacturer / Supplier</span>
                <span className="font-medium text-[#164B35]">{medicine.supplier || 'Unspecified'}</span>
                {medicine.supplierContact && (
                  <span className="text-xs text-gray-500 block flex items-center gap-1 mt-0.5">
                    <Phone className="w-3 h-3 text-gray-400" />
                    {medicine.supplierContact}
                  </span>
                )}
              </div>
            </div>

            {medicine.description && (
              <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                <span className="text-xs font-semibold text-gray-600 block mb-1">Therapeutic Indications</span>
                <p className="text-xs text-gray-700 leading-relaxed">{medicine.description}</p>
              </div>
            )}

            {medicine.notes && (
              <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-100">
                <span className="text-xs font-semibold text-amber-800 block mb-1">Staff Notes</span>
                <p className="text-xs text-gray-700 leading-relaxed">{medicine.notes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between px-6 py-4 bg-gray-50 border-t border-gray-200">
          <button
            onClick={() => {
              onClose();
              onDelete(medicine);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Batch</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-gray-600 hover:bg-gray-200 rounded-lg transition cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onEdit(medicine);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#247A50] hover:bg-[#1b5f3e] rounded-lg transition cursor-pointer shadow-xs"
            >
              <Edit2 className="w-4 h-4" />
              <span>Edit Details</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
