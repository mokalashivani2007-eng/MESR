import React, { useState, useEffect } from 'react';
import { X, AlertCircle, Save, Calendar, Pill, Building2, MapPin, Hash, Package } from 'lucide-react';
import { Medicine } from '../types';
import { useData } from '../context/DataContext';
import { getTodayKolkataString, normalizeDateString } from '../utils/expiry';

interface MedicineModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicineToEdit?: Medicine | null;
}

const CATEGORIES = [
  'Churna (Herbal Powder)',
  'Vati / Gutika (Tablets/Pills)',
  'Asava / Arishta (Fermented Liquids)',
  'Taila (Medicated Oils)',
  'Kashaya (Decoctions)',
  'Ghruta (Medicated Ghee)',
  'Lehya / Avaleha (Herbal Pastes)',
  'Bhasma / Rasayana (Calcinated Minerals)',
  'Guggulu (Resin Preparations)',
  'Syrup / Liquid Oral',
  'Capsules',
  'Ointment / Lepa',
  'Raw Herbals',
  'Other Formulation',
];

const UNITS = [
  'Tablets',
  'Bottles (450ml)',
  'Bottles (200ml)',
  'Bottles (100ml)',
  'Grams (100g Jar)',
  'Grams (500g Pack)',
  'Grams (1kg Pack)',
  'Capsules',
  'Packets',
  'Vials',
  'Boxes',
  'Units',
];

export const MedicineModal: React.FC<MedicineModalProps> = ({
  isOpen,
  onClose,
  medicineToEdit,
}) => {
  const { addMedicine, updateMedicine, rawMedicines } = useData();

  const [formData, setFormData] = useState({
    name: '',
    batchNumber: '',
    quantity: 1,
    unit: 'Bottles (450ml)',
    category: 'Asava / Arishta (Fermented Liquids)',
    manufacturingDate: '',
    expiryDate: '',
    supplier: '',
    supplierContact: '',
    storageLocation: 'Main Dispensary Shelf A',
    description: '',
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);

  useEffect(() => {
    if (medicineToEdit) {
      setFormData({
        name: medicineToEdit.name || '',
        batchNumber: medicineToEdit.batchNumber || '',
        quantity: medicineToEdit.quantity ?? 1,
        unit: medicineToEdit.unit || 'Bottles (450ml)',
        category: medicineToEdit.category || 'Asava / Arishta (Fermented Liquids)',
        manufacturingDate: medicineToEdit.manufacturingDate || '',
        expiryDate: medicineToEdit.expiryDate || '',
        supplier: medicineToEdit.supplier || '',
        supplierContact: medicineToEdit.supplierContact || '',
        storageLocation: medicineToEdit.storageLocation || 'Main Dispensary Shelf A',
        description: medicineToEdit.description || '',
        notes: medicineToEdit.notes || '',
      });
    } else {
      // Default to empty form for add
      setFormData({
        name: '',
        batchNumber: '',
        quantity: 1,
        unit: 'Bottles (450ml)',
        category: 'Asava / Arishta (Fermented Liquids)',
        manufacturingDate: '',
        expiryDate: '',
        supplier: '',
        supplierContact: '',
        storageLocation: 'Main Dispensary Shelf A',
        description: '',
        notes: '',
      });
    }
    setErrors({});
    setDuplicateWarning(null);
  }, [medicineToEdit, isOpen]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!formData.name.trim()) {
      errs.name = 'Medicine name is required.';
    }

    if (!formData.batchNumber.trim()) {
      errs.batchNumber = 'Batch number is required.';
    }

    if (formData.quantity === undefined || formData.quantity === null || formData.quantity < 0 || !Number.isInteger(Number(formData.quantity))) {
      errs.quantity = 'Quantity must be a non-negative whole integer.';
    }

    if (!formData.expiryDate) {
      errs.expiryDate = 'Expiry date is required.';
    } else {
      const normalized = normalizeDateString(formData.expiryDate);
      if (!normalized) {
        errs.expiryDate = 'Invalid expiry date format. Use YYYY-MM-DD.';
      }
    }

    if (formData.manufacturingDate && formData.expiryDate) {
      if (formData.manufacturingDate > formData.expiryDate) {
        errs.manufacturingDate = 'Manufacturing date cannot be after expiry date.';
      }
    }

    // Check duplicate batch number if creating new medicine
    if (!medicineToEdit) {
      const exists = rawMedicines.some(
        (m) => m.batchNumber.trim().toLowerCase() === formData.batchNumber.trim().toLowerCase()
      );
      if (exists) {
        errs.batchNumber = `Batch number "${formData.batchNumber}" already exists in inventory.`;
      }
    } else {
      // If editing, check if changed to another batch
      const existsOther = rawMedicines.some(
        (m) => m.id !== medicineToEdit.id && m.batchNumber.trim().toLowerCase() === formData.batchNumber.trim().toLowerCase()
      );
      if (existsOther) {
        errs.batchNumber = `Batch number "${formData.batchNumber}" is used by another medicine record.`;
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const payload = {
        name: formData.name.trim(),
        batchNumber: formData.batchNumber.trim(),
        quantity: Math.floor(Number(formData.quantity)),
        unit: formData.unit.trim(),
        category: formData.category.trim(),
        manufacturingDate: formData.manufacturingDate ? normalizeDateString(formData.manufacturingDate) || undefined : undefined,
        expiryDate: normalizeDateString(formData.expiryDate)!,
        supplier: formData.supplier.trim() || undefined,
        supplierContact: formData.supplierContact.trim() || undefined,
        storageLocation: formData.storageLocation.trim() || undefined,
        description: formData.description.trim() || undefined,
        notes: formData.notes.trim() || undefined,
        isSample: medicineToEdit?.isSample || false,
      };

      if (medicineToEdit) {
        await updateMedicine(medicineToEdit.id, payload);
      } else {
        await addMedicine(payload);
      }

      onClose();
    } catch (err: any) {
      setErrors({ form: err.message || 'Failed to save medicine record.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#DCEBDD] overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#164B35] text-white">
          <div className="flex items-center space-x-2">
            <Pill className="w-5 h-5 text-[#DCEBDD]" />
            <h2 className="text-lg font-bold">
              {medicineToEdit ? 'Edit Medicine Batch' : 'Add New Medicine Batch'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#DCEBDD] hover:bg-[#247A50] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {errors.form && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errors.form}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Medicine Name */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Medicine Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Ashwagandha Churna, Brahmi Vati"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className={`w-full px-3 py-2 text-sm rounded-lg border focus:outline-hidden transition ${
                  errors.name ? 'border-red-400 bg-red-50/30' : 'border-gray-300 focus:border-[#247A50] focus:ring-1 focus:ring-[#247A50]'
                }`}
                required
              />
              {errors.name && <p className="text-xs text-red-600 mt-1">{errors.name}</p>}
            </div>

            {/* Batch Number */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Batch Number <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g. AY-2026-081"
                  value={formData.batchNumber}
                  onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
                  className={`w-full px-3 py-2 text-sm rounded-lg border uppercase focus:outline-hidden transition ${
                    errors.batchNumber ? 'border-red-400 bg-red-50/30' : 'border-gray-300 focus:border-[#247A50]'
                  }`}
                  required
                />
              </div>
              {errors.batchNumber && <p className="text-xs text-red-600 mt-1">{errors.batchNumber}</p>}
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Ayurvedic Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Quantity <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value, 10) || 0 })}
                className={`w-full px-3 py-2 text-sm rounded-lg border focus:outline-hidden transition ${
                  errors.quantity ? 'border-red-400 bg-red-50/30' : 'border-gray-300 focus:border-[#247A50]'
                }`}
                required
              />
              {errors.quantity && <p className="text-xs text-red-600 mt-1">{errors.quantity}</p>}
            </div>

            {/* Unit */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Unit of Measurement
              </label>
              <select
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              >
                {UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>

            {/* Manufacturing Date */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Manufacturing Date (Optional)
              </label>
              <input
                type="date"
                value={formData.manufacturingDate}
                onChange={(e) => setFormData({ ...formData, manufacturingDate: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
              {errors.manufacturingDate && <p className="text-xs text-red-600 mt-1">{errors.manufacturingDate}</p>}
            </div>

            {/* Expiry Date */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Expiry Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.expiryDate}
                onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                className={`w-full px-3 py-2 text-sm rounded-lg border focus:outline-hidden transition ${
                  errors.expiryDate ? 'border-red-400 bg-red-50/30' : 'border-gray-300 focus:border-[#247A50]'
                }`}
                required
              />
              {errors.expiryDate && <p className="text-xs text-red-600 mt-1">{errors.expiryDate}</p>}
            </div>

            {/* Storage Location */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Storage Location (Rack / Shelf)
              </label>
              <input
                type="text"
                placeholder="e.g. Shelf A-03, Cold Store, Dispensing 1"
                value={formData.storageLocation}
                onChange={(e) => setFormData({ ...formData, storageLocation: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
            </div>

            {/* Supplier Name */}
            <div>
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Supplier / Manufacturer
              </label>
              <input
                type="text"
                placeholder="e.g. Arya Vaidya Sala Kottakkal, Dabur"
                value={formData.supplier}
                onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
            </div>

            {/* Supplier Contact */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Supplier Contact (Phone / Email)
              </label>
              <input
                type="text"
                placeholder="e.g. +91 9876543210 or supply@kottakkal.org"
                value={formData.supplierContact}
                onChange={(e) => setFormData({ ...formData, supplierContact: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
            </div>

            {/* Description & Indications */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Description / Formulation Details
              </label>
              <textarea
                rows={2}
                placeholder="Brief therapeutic indications or preparation details..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
            </div>

            {/* Notes */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#164B35] mb-1">
                Staff Notes & Handling Remarks
              </label>
              <textarea
                rows={2}
                placeholder="Special precautions, batch warnings..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 focus:border-[#247A50] focus:outline-hidden"
              />
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-[#247A50] rounded-lg hover:bg-[#1b5f3e] transition disabled:opacity-50 cursor-pointer shadow-xs"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving to Database...' : medicineToEdit ? 'Save Changes' : 'Save Medicine'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
