import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Clock,
  RefreshCw,
  User as UserIcon,
  Leaf,
  ShieldCheck,
  Calendar,
  LogOut,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { getTodayKolkataString } from '../utils/expiry';

interface HeaderProps {
  pageTitle: string;
  onOpenNotifications: () => void;
  onNavigate: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  pageTitle,
  onOpenNotifications,
  onNavigate,
}) => {
  const { currentUser, userProfile, logout } = useAuth();
  const { notifications, stats, runExpiryCheck } = useData();
  const [isChecking, setIsChecking] = useState(false);
  const [checkMessage, setCheckMessage] = useState<string | null>(null);

  const unreadCount = stats.unreadNotificationsCount;
  const todayKolkata = getTodayKolkataString();

  const handleManualCheck = async () => {
    setIsChecking(true);
    setCheckMessage(null);
    try {
      const res = await runExpiryCheck();
      setCheckMessage(`Checked: ${res.generated} new alerts generated`);
      setTimeout(() => setCheckMessage(null), 3500);
    } catch (err: any) {
      setCheckMessage('Check completed');
      setTimeout(() => setCheckMessage(null), 3000);
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <header className="bg-white border-b border-[#DCEBDD] sticky top-0 z-30 px-4 sm:px-6 py-3 flex items-center justify-between shadow-xs">
      {/* Page Title & Context */}
      <div className="flex items-center space-x-3">
        <div>
          <h1 className="text-xl font-bold text-[#164B35] leading-tight flex items-center gap-2">
            <span>{pageTitle}</span>
          </h1>
          <p className="text-xs text-gray-500 hidden sm:block">
            Ayurvedic Hospital Pharmacy • Asia/Kolkata (IST): <span className="font-medium text-[#247A50]">{todayKolkata}</span>
          </p>
        </div>
      </div>

      {/* Header Actions */}
      <div className="flex items-center space-x-3">
        {/* Run Expiry Check Button */}
        <button
          onClick={handleManualCheck}
          disabled={isChecking}
          title="Scan medicine inventory now and check for due expiry reminders"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#FAFBF8] border border-[#DCEBDD] text-[#164B35] hover:bg-[#DCEBDD]/40 transition disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#247A50] ${isChecking ? 'animate-spin' : ''}`} />
          <span className="hidden md:inline">Run Expiry Check</span>
        </button>

        {checkMessage && (
          <span className="text-xs font-medium text-[#247A50] bg-[#DCEBDD]/50 px-2 py-1 rounded hidden lg:inline">
            {checkMessage}
          </span>
        )}

        {/* Notifications Bell */}
        <div className="relative">
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg text-[#164B35] hover:bg-[#F1F4F1] transition focus:outline-hidden cursor-pointer"
            title="Expiry Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-5 min-w-[20px] px-1 items-center justify-center rounded-full bg-[#DC2626] text-[11px] font-bold text-white shadow-xs animate-pulse">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>
        </div>

        {/* User Profile Badge */}
        <div className="flex items-center pl-3 border-l border-gray-200 space-x-2">
          <div className="w-8 h-8 rounded-full bg-[#247A50] text-white flex items-center justify-center font-bold text-xs shadow-xs">
            {userProfile?.displayName ? userProfile.displayName.charAt(0).toUpperCase() : 'M'}
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-semibold text-[#164B35] truncate max-w-[140px]">
              {userProfile?.displayName || currentUser?.email?.split('@')[0]}
            </div>
            <div className="text-[10px] text-gray-500 capitalize">
              {userProfile?.role || 'Staff'}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
