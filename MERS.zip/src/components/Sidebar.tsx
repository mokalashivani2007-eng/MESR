import React from 'react';
import {
  LayoutDashboard,
  Pill,
  PlusCircle,
  FileSpreadsheet,
  AlertTriangle,
  Bell,
  FileText,
  Settings,
  LogOut,
  Leaf,
  CalendarCheck,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  onOpenAddModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  mobileOpen,
  setMobileOpen,
  onOpenAddModal,
}) => {
  const { logout } = useAuth();
  const { stats } = useData();

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'inventory',
      label: 'Medicine Inventory',
      icon: Pill,
      badge: stats.totalBatches > 0 ? stats.totalBatches : null,
    },
    {
      id: 'add-medicine',
      label: 'Add Medicine',
      icon: PlusCircle,
      action: () => onOpenAddModal(),
    },
    {
      id: 'upload',
      label: 'Upload Medicine File',
      icon: FileSpreadsheet,
    },
    {
      id: 'alerts',
      label: 'Expiry Alerts',
      icon: AlertTriangle,
      badge: stats.expiringSoonCount + stats.expiredCount > 0 ? stats.expiringSoonCount + stats.expiredCount : null,
      badgeColor: stats.expiredCount > 0 ? 'bg-[#DC2626]' : 'bg-[#F59E0B]',
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: Bell,
      badge: stats.unreadNotificationsCount > 0 ? stats.unreadNotificationsCount : null,
      badgeColor: 'bg-[#DC2626]',
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: FileText,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
    },
  ];

  const handleSelect = (item: (typeof navItems)[0]) => {
    if (item.action) {
      item.action();
    } else {
      onNavigate(item.id);
    }
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden transition-opacity"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#164B35] text-white flex flex-col shadow-xl transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-[#247A50]/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#247A50] border border-[#DCEBDD]/40 flex items-center justify-center text-white shadow-inner">
              <Leaf className="w-6 h-6 text-[#DCEBDD]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-wider text-white">MERS</span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-[#247A50] text-[#DCEBDD]">
                  Ayurveda
                </span>
              </div>
              <p className="text-[11px] text-[#DCEBDD]/80 font-medium leading-none mt-0.5">
                Medicine Expiry Reminder System
              </p>
            </div>
          </div>

          <div className="mt-3 px-2 py-1.5 bg-[#0f3626] rounded-md text-[10px] text-[#DCEBDD]/70 tracking-tight flex items-center gap-1">
            <CalendarCheck className="w-3 h-3 text-[#DCEBDD]" />
            <span>Track Medicines • Detect Expiry • Protect Patients</span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition cursor-pointer ${
                  isActive
                    ? 'bg-[#247A50] text-white shadow-xs font-semibold'
                    : 'text-[#DCEBDD] hover:bg-[#1f6648] hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#DCEBDD]' : 'text-[#DCEBDD]/80'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge !== null && item.badge !== undefined && (
                  <span
                    className={`px-2 py-0.5 text-[11px] font-bold rounded-full text-white ${
                      item.badgeColor || 'bg-[#247A50] border border-[#DCEBDD]/40'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Quick Expiry Status Glance */}
        <div className="p-3 mx-3 mb-3 bg-[#0f3626]/80 rounded-lg border border-[#247A50]/40 text-xs">
          <div className="text-[11px] font-semibold text-[#DCEBDD] uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>Inventory Health</span>
            <ShieldAlert className="w-3.5 h-3.5 text-[#F59E0B]" />
          </div>
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="p-1.5 bg-black/20 rounded">
              <div className="text-sm font-bold text-emerald-300">{stats.safeCount}</div>
              <div className="text-[10px] text-gray-300">Safe</div>
            </div>
            <div className="p-1.5 bg-black/20 rounded">
              <div className="text-sm font-bold text-amber-400">{stats.expiringSoonCount}</div>
              <div className="text-[10px] text-gray-300">Expiring Soon</div>
            </div>
          </div>
        </div>

        {/* Logout Section */}
        <div className="p-3 border-t border-[#247A50]/60">
          <button
            onClick={() => logout()}
            className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm text-[#DCEBDD] hover:bg-[#DC2626]/20 hover:text-red-200 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-red-300" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
