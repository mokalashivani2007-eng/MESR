import React, { useState } from 'react';
import { Sparkles, Trash2, Check, RefreshCw } from 'lucide-react';
import { useData } from '../context/DataContext';

export const SampleDataBanner: React.FC = () => {
  const { medicines, loadSampleData, clearSampleData } = useData();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const sampleCount = medicines.filter((m) => m.isSample).length;

  const handleLoad = async () => {
    setLoading(true);
    setMessage(null);
    try {
      const count = await loadSampleData();
      setMessage(`Successfully loaded ${count} demonstration batches.`);
      setTimeout(() => setMessage(null), 4000);
    } catch (err: any) {
      setMessage(err.message || 'Error loading sample data.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = async () => {
    setLoading(true);
    setMessage(null);
    try {
      const count = await clearSampleData();
      setMessage(`Removed ${count} sample demonstration records.`);
      setTimeout(() => setMessage(null), 4000);
    } catch (err: any) {
      setMessage(err.message || 'Error clearing sample data.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#FAFBF8] border border-[#DCEBDD] rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
      <div className="flex items-center space-x-2.5">
        <div className="p-2 rounded-lg bg-[#DCEBDD]/60 text-[#164B35]">
          <Sparkles className="w-4 h-4 text-[#247A50]" />
        </div>
        <div>
          <div className="text-xs font-bold text-[#164B35] flex items-center gap-2">
            <span>Fictional Demonstration Data</span>
            {sampleCount > 0 ? (
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-700">
                {sampleCount} sample {sampleCount === 1 ? 'batch' : 'batches'} loaded
              </span>
            ) : (
              <span className="text-[11px] font-normal text-gray-500">None currently loaded</span>
            )}
          </div>
          <p className="text-[11px] text-gray-600 mt-0.5">
            Test expiry calculations for safe, expiring today, expiring in 7 days, and expired batches.
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-2 self-end sm:self-center shrink-0">
        {message && (
          <span className="text-xs font-medium text-[#247A50] bg-emerald-50 px-2 py-1 rounded">
            {message}
          </span>
        )}

        {sampleCount === 0 ? (
          <button
            onClick={handleLoad}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#247A50] text-white hover:bg-[#1b5f3e] transition disabled:opacity-50 cursor-pointer shadow-xs"
          >
            {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>Load Sample Batches</span>
          </button>
        ) : (
          <button
            onClick={handleClear}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 transition disabled:opacity-50 cursor-pointer"
          >
            {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            <span>Remove Sample Data</span>
          </button>
        )}
      </div>
    </div>
  );
};
