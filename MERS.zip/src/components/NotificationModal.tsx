import React, { useState } from 'react';
import {
  X,
  Bell,
  CheckCheck,
  Clock,
  AlertTriangle,
  AlertOctagon,
  Calendar,
  ExternalLink,
  Trash2,
  Filter,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { ExpiryNotification } from '../types';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMedicine: (medicineId: string) => void;
  onNavigateToNotifications: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  onSelectMedicine,
  onNavigateToNotifications,
}) => {
  const { notifications, markNotificationRead, markAllNotificationsRead, deleteNotification } = useData();
  const [filter, setFilter] = useState<'all' | 'unread' | 'expired' | 'soon'>('all');

  if (!isOpen) return null;

  const filtered = notifications.filter((n) => {
    if (filter === 'unread') return !n.isRead;
    if (filter === 'expired') return n.alertType === 'expired';
    if (filter === 'soon') return n.alertType !== 'expired';
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end p-4 sm:p-6 bg-black/30 backdrop-blur-2xs">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-[#DCEBDD] overflow-hidden flex flex-col max-h-[88vh] animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 bg-[#164B35] text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-[#DCEBDD]" />
            <h3 className="font-bold text-base">Expiry Notifications</h3>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#DC2626] text-white">
                {unreadCount} unread
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#DCEBDD] hover:bg-[#247A50] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="px-4 py-2.5 bg-[#FAFBF8] border-b border-[#DCEBDD] flex items-center justify-between gap-1 text-xs">
          <div className="flex items-center space-x-1 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded-full font-medium transition cursor-pointer ${
                filter === 'all' ? 'bg-[#247A50] text-white' : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-2.5 py-1 rounded-full font-medium transition cursor-pointer ${
                filter === 'unread' ? 'bg-[#247A50] text-white' : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              Unread ({unreadCount})
            </button>
            <button
              onClick={() => setFilter('soon')}
              className={`px-2.5 py-1 rounded-full font-medium transition cursor-pointer ${
                filter === 'soon' ? 'bg-[#F59E0B] text-white' : 'text-amber-700 hover:bg-amber-100'
              }`}
            >
              Expiring Soon
            </button>
            <button
              onClick={() => setFilter('expired')}
              className={`px-2.5 py-1 rounded-full font-medium transition cursor-pointer ${
                filter === 'expired' ? 'bg-[#DC2626] text-white' : 'text-red-700 hover:bg-red-100'
              }`}
            >
              Expired
            </button>
          </div>

          {unreadCount > 0 && (
            <button
              onClick={() => markAllNotificationsRead()}
              className="text-[#247A50] hover:text-[#164B35] font-semibold text-xs flex items-center gap-1 shrink-0 ml-1 cursor-pointer"
              title="Mark all as read"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Read All</span>
            </button>
          )}
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-100 p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <Bell className="w-8 h-8 mx-auto text-gray-300 mb-2" />
              <p className="text-sm font-medium">No notifications in this filter</p>
              <p className="text-xs text-gray-400 mt-1">All batches are monitored daily.</p>
            </div>
          ) : (
            filtered.map((item) => {
              const isExpired = item.alertType === 'expired';
              return (
                <div
                  key={item.id}
                  className={`p-3 rounded-xl transition flex flex-col gap-1.5 ${
                    item.isRead ? 'bg-white hover:bg-[#FAFBF8]' : 'bg-[#DCEBDD]/25 border border-[#DCEBDD]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start space-x-2">
                      <div className="mt-0.5">
                        {isExpired ? (
                          <AlertOctagon className="w-4 h-4 text-[#DC2626] shrink-0" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0" />
                        )}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-[#164B35] flex items-center gap-1.5">
                          <span>{item.medicineName}</span>
                          {!item.isRead && (
                            <span className="w-2 h-2 rounded-full bg-[#DC2626] inline-block" />
                          )}
                        </div>
                        <div className="text-[11px] text-gray-500">
                          Batch: <span className="font-medium text-gray-700">{item.batchNumber}</span> • Qty: {item.quantity}
                        </div>
                      </div>
                    </div>

                    <div className="text-[10px] text-gray-400 shrink-0">
                      {new Date(item.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  <p className="text-xs text-gray-700 pl-6 leading-relaxed">
                    {item.message}
                  </p>

                  <div className="flex items-center justify-between pl-6 pt-1 text-[11px]">
                    <span className="text-gray-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#247A50]" />
                      Exp: {item.expiryDate}
                    </span>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          onClose();
                          onSelectMedicine(item.medicineId);
                        }}
                        className="text-[#247A50] hover:underline font-semibold flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>View Batch</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>

                      {!item.isRead && (
                        <button
                          onClick={() => markNotificationRead(item.id)}
                          className="text-gray-500 hover:text-gray-800 text-[11px] cursor-pointer"
                        >
                          Mark read
                        </button>
                      )}

                      <button
                        onClick={() => deleteNotification(item.id)}
                        className="text-gray-400 hover:text-red-500 p-0.5 cursor-pointer"
                        title="Dismiss"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#FAFBF8] border-t border-[#DCEBDD] flex items-center justify-between text-xs text-gray-600">
          <span>Persistent Firestore storage</span>
          <button
            onClick={() => {
              onClose();
              onNavigateToNotifications();
            }}
            className="text-[#247A50] font-bold hover:underline cursor-pointer"
          >
            Open Full Notification Center &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
